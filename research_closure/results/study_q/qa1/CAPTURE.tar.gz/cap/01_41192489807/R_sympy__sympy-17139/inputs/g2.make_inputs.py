def make_inputs(rng, n):
    import sympy
    from sympy import Symbol, sin, cos, I, Rational, pi, exp

    x = Symbol('x')
    y = Symbol('y')
    z_complex = Symbol('z_complex', complex=True)
    z_real = Symbol('z_real', real=True)
    z_imag = Symbol('z_imag', imaginary=True)

    def h(val):
        return 1 - val

    pairs = [
        (sin, cos),
        (cos, sin)
    ]

    items = []

    for _ in range(n):
        f, g = rng.choice(pairs)
        max_val = rng.choice([2, 4, 6, 8, 10, 16])
        pow_flag = rng.choice([True, False])
        arg = rng.choice([x, y, 2 * x, x + y, x * y])

        is_complex_case = rng.random() < 0.5

        if is_complex_case:
            # Exponents that are imaginary, complex, or not known to be real
            exp_choices = [
                I,
                -I,
                2 * I,
                1 + I,
                2 - 3 * I,
                x * I,
                z_complex,
                z_imag,
                I * pi,
                Rational(1, 2) * I,
            ]
            chosen_exp = rng.choice(exp_choices)
        else:
            # Exponents that are real or integer
            exp_choices = [
                -2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 16,
                Rational(1, 2), Rational(3, 2), Rational(5, 2),
                z_real,
                pi
            ]
            chosen_exp = rng.choice(exp_choices)

        # Build base expression
        base = f(arg)
        # Sometimes test as an isolated Pow, sometimes in an Add/Mul expression
        variant = rng.choice(['single', 'add', 'mul'])
        if variant == 'single':
            expr = base ** chosen_exp
        elif variant == 'add':
            expr = base ** chosen_exp + g(arg) ** 2
        else:
            expr = base ** chosen_exp * (base ** 2)

        args = (expr, f, g, h, max_val, pow_flag)
        items.append((None, args, {}))

    return items
