def make_inputs(rng, n):
    items = []
    schemes = ["http://", "https://"]

    # Typical valid/invalid URLs not specifically triggering the '.' leading issue
    normal_hosts = [
        "example.com",
        "sub.example.com",
        "localhost",
        "127.0.0.1",
        "[::1]",
        "google.com/search",
        "api.github.com/repos",
        "*.example.com",
        "*example.com",
        "xn--bcher-kva.example",
        "b\u00fccher.example",
        "ex\u00e4mple.com",
        "invalid..com",
    ]

    # Problematic hosts that start with '.' (ASCII) or edge cases
    issue_hosts = [
        ".example.com",
        ".example.org/path",
        "..example.com",
        ".",
        "..",
        ".com",
        ".org/test",
        ".sub.domain.co.uk",
        ".local",
        ".127.0.0.1",
        ".*",
        ".*.example.com",
    ]

    for i in range(n):
        req = target_class()
        params = None
        if rng.random() < 0.2:
            params = {rng.choice(["q", "page", "id"]): rng.choice(["1", "test", "val&key"])}
        elif rng.random() < 0.1:
            params = "key=val"

        # Half normal, half issue-focused
        if i % 2 == 0:
            scheme = rng.choice(schemes)
            host = rng.choice(normal_hosts)
            path = rng.choice(["", "/", "/foo", "/bar?baz=1", "#frag"])
            url = f"{scheme}{host}{path}"
            if rng.random() < 0.1:
                url = url.encode("utf-8")
        else:
            scheme = rng.choice(schemes)
            host = rng.choice(issue_hosts)
            path = rng.choice(["", "/", "/a/b/c", "?x=y", "#section"])
            url = f"{scheme}{host}{path}"
            if rng.random() < 0.2:
                url = url.encode("utf-8")

        items.append((req, (url, params), {}))

    return items
