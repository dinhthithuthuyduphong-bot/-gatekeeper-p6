from astropy.table import Table, Column
import numpy as np

def make_inputs(rng, n):
    items = []
    
    # We will instantiate HTML objects and call write(table).
    # HTML class has self.data which is an instance of TableData or similar core class.
    # When formats are supplied to ascii.write(..., formats=...), ascii.write sets
    # writer.data.formats = formats.
    # In HTML.write, the fix sets self.data.cols = cols and calls self.data._set_col_formats().
    
    for i in range(n):
        # Create HTML instance
        htmldict = {}
        if rng.random() < 0.3:
            htmldict['table_id'] = f"table_{rng.randint(1, 100)}"
        if rng.random() < 0.3:
            htmldict['table_class'] = f"class_{rng.randint(1, 10)}"
        if rng.random() < 0.2:
            htmldict['multicol'] = rng.choice([True, False])
            
        receiver = module.HTML(htmldict=htmldict)
        
        # Build a table
        nrows = rng.randint(1, 5)
        names = ['a', 'b', 'c'][:rng.randint(1, 3)]
        
        cols = []
        for name in names:
            col_type = rng.choice(['float', 'int', 'str', '2d_float'])
            if col_type == 'float':
                data = [rng.uniform(-1000.0, 1000.0) for _ in range(nrows)]
            elif col_type == 'int':
                data = [rng.randint(-100, 100) for _ in range(nrows)]
            elif col_type == 'str':
                data = [f"val_{rng.randint(0, 50)}" for _ in range(nrows)]
            elif col_type == '2d_float':
                data = np.array([[rng.uniform(0, 10) for _ in range(2)] for _ in range(nrows)])
            cols.append(Column(data, name=name))
            
        table = Table(cols)
        
        # In about half the cases, test formats
        if i % 2 == 1:
            formats = {}
            for name in names:
                if rng.random() < 0.7:
                    fmt_choice = rng.choice(['float_fmt', 'callable', 'str_fmt'])
                    if fmt_choice == 'float_fmt':
                        dec = rng.randint(1, 4)
                        formats[name] = f"%.{dec}f"
                    elif fmt_choice == 'callable':
                        formats[name] = lambda x: f"fmt_{x}"
                    elif fmt_choice == 'str_fmt':
                        formats[name] = "{:.2e}"
            receiver.data.formats = formats
        else:
            # Ordinary cases, no formats or None/empty dict
            if rng.random() < 0.5:
                receiver.data.formats = {}
            else:
                receiver.data.formats = None
                
        items.append((receiver, (table,), {}))
        
    return items
