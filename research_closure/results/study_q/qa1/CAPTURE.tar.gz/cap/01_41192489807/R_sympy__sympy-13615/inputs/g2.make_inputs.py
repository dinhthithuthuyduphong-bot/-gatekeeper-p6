def make_inputs(rng, n):
    import sympy
    from sympy import Symbol, S, Interval, FiniteSet, Union, EmptySet, ProductSet, Complement

    x = Symbol('x')
    y = Symbol('y')
    z = Symbol('z')
    symbols = [x, y, z]

    def random_number():
        return rng.choice([-10, -5, -2, -1, 0, 1, 2, 5, 10])

    def random_interval():
        a = random_number()
        b = a + rng.choice([0, 1, 2, 5, 10])
        left_open = rng.choice([True, False])
        right_open = rng.choice([True, False])
        return Interval(a, b, left_open, right_open)

    def random_ordinary_set():
        choice = rng.choice(['interval', 'finite_num', 'union', 'empty'])
        if choice == 'interval':
            return random_interval()
        elif choice == 'finite_num':
            elements = [random_number() for _ in range(rng.randint(1, 4))]
            return FiniteSet(*elements)
        elif choice == 'union':
            return Union(random_interval(), FiniteSet(random_number()))
        elif choice == 'empty':
            return S.EmptySet

    def random_mixed_finite_set():
        num_symbols = rng.randint(1, 2)
        num_numbers = rng.randint(1, 2)
        sym_elems = rng.sample(symbols, num_symbols)
        num_elems = [random_number() for _ in range(num_numbers)]
        return FiniteSet(*(sym_elems + num_elems))

    items = []
    for i in range(n):
        # Around half: target the issue where 'other' is a FiniteSet containing symbols/mixed
        # receiver is 'self' (the set being subtracted), arg is 'other' (the set being subtracted from).
        # Notice _complement is called as self._complement(other), meaning other - self!
        if i % 2 == 0:
            other = random_mixed_finite_set()
            receiver = rng.choice([
                random_interval(),
                FiniteSet(*[random_number() for _ in range(rng.randint(1, 3))]),
                Union(random_interval(), FiniteSet(random_number())),
                Interval(-10, 10),
                Interval(0, 5)
            ])
            items.append((receiver, (other,), {}))
        else:
            # Ordinary cases
            case_type = rng.choice(['interval_interval', 'union', 'empty', 'product', 'finite_num'])
            if case_type == 'interval_interval':
                receiver = random_interval()
                other = random_interval()
            elif case_type == 'union':
                receiver = random_ordinary_set()
                other = Union(random_interval(), random_interval())
            elif case_type == 'empty':
                receiver = random_ordinary_set()
                other = S.EmptySet
            elif case_type == 'product':
                receiver = ProductSet(random_interval(), random_interval())
                other = ProductSet(random_interval(), random_interval())
            else:
                receiver = random_ordinary_set()
                other = FiniteSet(*[random_number() for _ in range(rng.randint(1, 4))])
            items.append((receiver, (other,), {}))

    return items
