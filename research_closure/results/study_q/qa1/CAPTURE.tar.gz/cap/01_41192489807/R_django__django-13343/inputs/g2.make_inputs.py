def make_inputs(rng, n):
    from django.conf import settings
    if not settings.configured:
        settings.configure(DEFAULT_FILE_STORAGE="django.core.files.storage.FileSystemStorage")

    from django.core.files.storage import Storage, FileSystemStorage, default_storage
    FileField = module.FileField

    class CustomStorage(Storage):
        def __init__(self, option="default"):
            self.option = option

    def get_custom_storage_1():
        return CustomStorage(option="storage_1")

    def get_custom_storage_2():
        return FileSystemStorage(location="/tmp/custom")

    def get_default_storage():
        return default_storage

    callable_storages = [
        get_custom_storage_1,
        get_custom_storage_2,
        FileSystemStorage,
        CustomStorage,
        get_default_storage,
    ]

    fixed_storages = [
        None,
        default_storage,
        FileSystemStorage(location="/tmp/media"),
        CustomStorage(option="fixed"),
    ]

    items = []
    for i in range(n):
        use_callable = (i % 2 == 1)

        upload_to_choices = [
            "",
            "uploads/",
            "uploads/%Y/%m/%d/",
            lambda instance, filename: f"dyn/{filename}",
        ]
        upload_to = rng.choice(upload_to_choices)
        max_length = rng.choice([100, 200, 255])
        verbose_name = rng.choice([None, "Test File", "A file field"])
        name = rng.choice([None, "file_field", "doc"])

        kwargs = {}
        if max_length != 100 or rng.random() < 0.3:
            kwargs["max_length"] = max_length

        if use_callable:
            storage = rng.choice(callable_storages)
        else:
            storage = rng.choice(fixed_storages)

        field_kwargs = {
            "upload_to": upload_to,
            "verbose_name": verbose_name,
            "name": name,
            **kwargs,
        }
        if storage is not None:
            field_kwargs["storage"] = storage

        field = FileField(**field_kwargs)
        items.append((field, (), {}))

    return items
