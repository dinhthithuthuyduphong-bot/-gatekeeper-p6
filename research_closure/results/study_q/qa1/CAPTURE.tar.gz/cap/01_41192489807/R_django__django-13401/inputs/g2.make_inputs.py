def make_inputs(rng, n):
    Field = module.Field

    class FakeModel:
        def __init__(self, app_label, model_name):
            self._meta = type('Meta', (), {'app_label': app_label, 'model_name': model_name})()

    models = [
        FakeModel('app_a', 'model_a'),
        FakeModel('app_a', 'model_b'),
        FakeModel('app_b', 'model_a'),
        None,
    ]

    items = []
    for _ in range(n):
        f1 = Field()
        # Decide scenario:
        # 0: totally standard comparison (different fields, possibly non-field other)
        # 1: same field (identity)
        # 2: same creation_counter, different models (core issue scenario)
        # 3: same creation_counter, same model
        # 4: same creation_counter, one has model, other doesn't
        # 5: different creation_counter, various model combinations
        # 6: comparison with non-Field object
        scenario = rng.choice([0, 1, 2, 2, 3, 4, 5, 6])

        if scenario == 0:
            f2 = Field()
            items.append((f1, (f2,), {}))
        elif scenario == 1:
            if rng.random() < 0.5:
                f1.model = rng.choice(models)
            items.append((f1, (f1,), {}))
        elif scenario == 2:
            f2 = Field()
            f2.creation_counter = f1.creation_counter
            m1 = rng.choice(models[:3])
            m2 = rng.choice([m for m in models[:3] if m != m1])
            f1.model = m1
            f2.model = m2
            items.append((f1, (f2,), {}))
        elif scenario == 3:
            f2 = Field()
            f2.creation_counter = f1.creation_counter
            m = rng.choice(models[:3])
            f1.model = m
            f2.model = m
            items.append((f1, (f2,), {}))
        elif scenario == 4:
            f2 = Field()
            f2.creation_counter = f1.creation_counter
            m = rng.choice(models[:3])
            if rng.random() < 0.5:
                f1.model = m
            else:
                f2.model = m
            items.append((f1, (f2,), {}))
        elif scenario == 5:
            f2 = Field()
            if rng.random() < 0.5:
                f1.model = rng.choice(models)
            if rng.random() < 0.5:
                f2.model = rng.choice(models)
            items.append((f1, (f2,), {}))
        else:
            other = rng.choice([None, 123, "string", object(), ()])
            items.append((f1, (other,), {}))

    return items
