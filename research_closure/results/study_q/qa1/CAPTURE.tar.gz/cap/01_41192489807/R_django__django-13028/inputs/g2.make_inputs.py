def make_inputs(rng, n):
    Query = module.Query

    class DummyExpression:
        def __init__(self, filterable=True, sources=None):
            self.filterable = filterable
            self._sources = sources or []

        def resolve_expression(self, *args, **kwargs):
            return self

        def get_source_expressions(self):
            return self._sources

    class NonExpressionWithFilterable:
        def __init__(self, filterable):
            self.filterable = filterable

    class PlainObject:
        pass

    items = []
    for i in range(n):
        # We don't need a real Django model for check_filterable since it doesn't touch self.model
        q = Query(model=None)
        
        # Decide category:
        # Half ordinary (primitives, standard DummyExpressions with filterable=True/False, etc.)
        # Half issue-related (objects with filterable=False or filterable truthy/falsy, but lacking resolve_expression)
        choice = rng.choice(["ordinary", "issue"]) if i > 0 else "issue"
        
        if choice == "ordinary":
            sub_choice = rng.choice([
                "primitive",
                "expr_filterable_true",
                "expr_filterable_false",
                "expr_nested",
                "expr_nested_invalid",
            ])
            if sub_choice == "primitive":
                val = rng.choice([
                    123,
                    "hello",
                    None,
                    True,
                    False,
                    3.14,
                    [1, 2, 3],
                    {"key": "value"},
                ])
            elif sub_choice == "expr_filterable_true":
                val = DummyExpression(filterable=True)
            elif sub_choice == "expr_filterable_false":
                val = DummyExpression(filterable=False)
            elif sub_choice == "expr_nested":
                depth = rng.randint(1, 3)
                curr = DummyExpression(filterable=True)
                for _ in range(depth):
                    curr = DummyExpression(filterable=True, sources=[curr])
                val = curr
            else:  # expr_nested_invalid
                invalid_expr = DummyExpression(filterable=False)
                curr = DummyExpression(filterable=True, sources=[invalid_expr])
                val = curr
        else:
            # Issue-related: objects that have filterable attribute (esp. filterable=False)
            # but do NOT have resolve_expression (like Model instances with a field called filterable)
            filterable_val = rng.choice([False, 0, "", None, [], ()])
            nested = rng.choice([False, True])
            non_expr = NonExpressionWithFilterable(filterable=filterable_val)
            if nested:
                # Placed inside an expression's source_expressions
                val = DummyExpression(filterable=True, sources=[non_expr])
            else:
                val = non_expr

        items.append((q, (val,), {}))

    return items
