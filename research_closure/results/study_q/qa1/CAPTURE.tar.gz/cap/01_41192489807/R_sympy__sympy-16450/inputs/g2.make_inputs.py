def make_inputs(rng, n):
    from sympy import Symbol, sin, cos, exp, log, Matrix, Tuple

    # Safe combinations of assumptions that do not contradict each other
    # and do not contradict positive=True
    assumption_sets = [
        {'finite': True},
        {'finite': False},
        {'integer': True},
        {'rational': True},
        {'prime': True},
        {'even': True},
        {'odd': True},
        {'integer': True, 'finite': True},
        {'even': True, 'finite': True},
        {'odd': True, 'finite': True},
        {'prime': True, 'finite': True},
        {'rational': True, 'finite': True},
        {'real': True, 'finite': True},
        {'commutative': False},
    ]

    items = []
    for i in range(n):
        test_assumptions = (i % 2 == 1)

        if test_assumptions:
            assump1 = rng.choice(assumption_sets)
            assump2 = rng.choice(assumption_sets)
            s1 = Symbol('x%d' % i, **assump1)
            s2 = Symbol('y%d' % i, **assump2)
            s3 = Symbol('z%d' % i, finite=True)

            expr_type = rng.choice(['single', 'expr', 'iterable'])
            if expr_type == 'single':
                eq = s1
            elif expr_type == 'expr':
                eq = s1 * s2 + log(s1) + s3**2
            else:
                eq_type = rng.choice([list, tuple, Tuple])
                eq = eq_type([s1, s1 + s2, s2 * s3])
        else:
            var_names = ['a', 'b', 'c', 'u', 'v', 'w']
            num_vars = rng.randint(1, 3)
            chosen = rng.sample(var_names, num_vars)
            syms = [Symbol('%s_%d' % (c, i)) for c in chosen]

            form = rng.choice(['add', 'pow', 'log', 'matrix', 'list', 'symbol'])
            if form == 'symbol':
                eq = syms[0]
            elif form == 'add':
                eq = sum(syms)
            elif form == 'pow':
                base = syms[0]
                exp_ = syms[1] if len(syms) > 1 else rng.randint(2, 5)
                eq = base**exp_
            elif form == 'log':
                eq = log(syms[0] + 1)
            elif form == 'matrix':
                eq = Matrix([[syms[0], 1], [0, syms[-1]]])
            else:
                eq = [syms[0]**2 - 4, syms[0]]

        items.append((None, (eq,), {}))

    return items
