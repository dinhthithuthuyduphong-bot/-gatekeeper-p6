from unittest.mock import MagicMock
from django.db.backends.ddl_references import IndexName


class FakeField:
    def __init__(self, name, column=None):
        self.name = name
        self.column = column or name


class FakeMeta:
    def __init__(self, db_table, fields, constraints=None, indexes=None):
        self.db_table = db_table
        self._fields = {f.name: f for f in fields}
        self.constraints = constraints or []
        self.indexes = indexes or []

    def get_field(self, name):
        return self._fields[name]


class FakeModel:
    def __init__(self, db_table, fields, constraints=None, indexes=None):
        self._meta = FakeMeta(db_table, fields, constraints, indexes)


def make_inputs(rng, n):
    items = []

    for i in range(n):
        conn = MagicMock()
        conn.ops.quote_name = lambda name: f'"{name}"'
        conn.ops.max_name_length = lambda: 63
        conn.features.can_rollback_ddl = False

        is_issue_scenario = i % 2 == 1

        allows_multiple = True if is_issue_scenario else rng.choice([True, False])
        conn.features.allows_multiple_constraints_on_same_fields = allows_multiple

        editor = target_class(conn, collect_sql=True)
        editor.execute = MagicMock()
        editor._delete_constraint_sql = MagicMock(
            return_value="ALTER TABLE ... DROP CONSTRAINT"
        )

        table_name = rng.choice(["test_table", "app_model", "auth_user", "item"])
        col_names = rng.choice([["id"], ["code"], ["a", "b"], ["slug"]])
        fields = [FakeField(c, c) for c in col_names]
        model = FakeModel(table_name, fields)

        default_uniq_name = str(
            IndexName(table_name, col_names, "_uniq", editor._create_index_name)
        )

        if is_issue_scenario:
            other_name = rng.choice([f"{table_name}_pkey", "custom_uniq_idx", "uniq_2"])
            constraint_names = [other_name, default_uniq_name]
            if rng.random() < 0.5:
                rng.shuffle(constraint_names)
            constraint_kwargs = {"unique": True}
        else:
            case = rng.choice(["one_matched", "zero_matched", "other_multi"])
            if case == "one_matched":
                constraint_names = [
                    rng.choice([default_uniq_name, f"{table_name}_{col_names[0]}_uniq"])
                ]
            elif case == "zero_matched":
                constraint_names = []
            else:
                constraint_names = ["some_constraint_1", "some_constraint_2"]
            constraint_kwargs = rng.choice(
                [
                    {"unique": True},
                    {"index": True},
                    {"unique": True, "primary_key": False},
                    {},
                ]
            )

        editor._constraint_names = MagicMock(return_value=constraint_names)

        sql = "ALTER TABLE %(table)s DROP CONSTRAINT %(constraint)s"
        args = (model, col_names, constraint_kwargs, sql)
        kwargs = {}

        items.append((editor, args, kwargs))

    return items
