def make_inputs(rng, n):
    Point = module.Point
    items = []

    def random_coord():
        choices = [
            lambda: rng.randint(-10, 10),
            lambda: rng.choice([-2, -1, 0, 1, 2, 5]),
            lambda: round(rng.uniform(-5.0, 5.0), 2),
        ]
        return rng.choice(choices)()

    def random_point(dim):
        coords = [random_coord() for _ in range(dim)]
        return Point(*coords)

    # Half ordinary (same dimension), half mismatched dimensions (as per the issue/fix)
    n_diff = n // 2
    n_same = n - n_diff

    # Ordinary cases: same dimension (mostly 2D and 3D, occasionally other dims)
    for _ in range(n_same):
        dim = rng.choice([2, 3, 1, 4])
        p1 = random_point(dim)
        p2 = random_point(dim)
        items.append((p1, (p2,), {}))

    # Mismatched dimension cases: len(p1) != len(p2)
    # Particularly Point2D vs Point3D, or 1D vs 2D, 2D vs 3D, 1D vs 3D, etc.
    for _ in range(n_diff):
        dim1 = rng.choice([1, 2, 3, 4])
        dim2 = rng.choice([d for d in [1, 2, 3, 4] if d != dim1])
        p1 = random_point(dim1)
        p2 = random_point(dim2)
        items.append((p1, (p2,), {}))

    rng.shuffle(items)
    return items
