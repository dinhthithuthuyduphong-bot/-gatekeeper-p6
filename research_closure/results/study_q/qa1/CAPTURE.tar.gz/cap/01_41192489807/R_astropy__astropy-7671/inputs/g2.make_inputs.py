import types


def make_inputs(rng, n):
    items = []

    # Pre-construct mock modules with diverse __version__ formats
    mock_versions = [
        "1.14.3",
        "1.14.0",
        "1.14",
        "2.0.0",
        "0.12.1",
        "1.15.0rc1",
        "1.13.2",
        "3.0.0.dev1",
        "1.2.3.4",
    ]

    mock_modules = []
    for i, v in enumerate(mock_versions):
        mod = types.ModuleType(f"mock_mod_{i}")
        mod.__version__ = v
        mock_modules.append(mod)

    # Issue-specific versions that contain dev, rc, a, b, post tags etc.
    # When have_version has 3 components (e.g. 1.14.3) and required version has
    # dev/rc tag directly after major.minor (e.g. 1.14dev, 1.14rc1), LooseVersion
    # compares int (from .3) with str ('dev') and raises TypeError.
    tricky_req_versions = [
        "1.14dev",
        "1.14.dev",
        "1.14dev1",
        "1.14rc1",
        "1.14a1",
        "1.14b2",
        "1.14post1",
        "2.0dev",
        "2.0rc2",
        "0.12dev",
        "1.13rc",
        "1.15dev",
        "1.14.0dev",
        "1.14.0rc1",
    ]

    # Ordinary version strings without prerelease/postrelease suffixes
    ordinary_req_versions = [
        "1.14",
        "1.14.0",
        "1.14.2",
        "1.14.3",
        "1.14.4",
        "1.13",
        "1.13.1",
        "1.15",
        "2.0",
        "0.11",
        "0.12",
        "0.13",
    ]

    for _ in range(n):
        # Pick module
        mod = rng.choice(mock_modules)

        # Decide whether to test the tricky bug case or normal case
        is_bug_case = rng.random() < 0.5
        if is_bug_case:
            ver = rng.choice(tricky_req_versions)
        else:
            ver = rng.choice(ordinary_req_versions)

        inclusive = rng.choice([True, False])
        args = (mod, ver)
        kwargs = {"inclusive": inclusive}

        items.append((None, args, kwargs))

    return items
