import numpy as np
import scipy.sparse as sp


def make_inputs(rng, n):
    items = []
    # Available kernels and solver types in BaseLibSVM
    # LIBSVM_IMPL = ['c_svc', 'nu_svc', 'one_class', 'epsilon_svr', 'nu_svr']
    # kernel: 'linear', 'poly', 'rbf', 'sigmoid', 'precomputed'

    class DummyEstimator(target_class):
        _impl = "epsilon_svr"

        def __init__(
            self,
            kernel="linear",
            degree=3,
            gamma="auto",
            coef0=0.0,
            tol=1e-3,
            C=1.0,
            nu=0.5,
            epsilon=0.1,
            shrinking=True,
            probability=False,
            cache_size=200,
            class_weight=None,
            verbose=False,
            max_iter=-1,
            random_state=None,
        ):
            super().__init__(
                kernel=kernel,
                degree=degree,
                gamma=gamma,
                coef0=coef0,
                tol=tol,
                C=C,
                nu=nu,
                epsilon=epsilon,
                shrinking=shrinking,
                probability=probability,
                cache_size=cache_size,
                class_weight=class_weight,
                verbose=verbose,
                max_iter=max_iter,
                random_state=random_state,
            )

    for i in range(n):
        # Decide if this should be an edge case (empty support_vectors_, e.g. large epsilon for SVR)
        # or an ordinary case
        is_edge_case = (i % 2) == 0

        if is_edge_case:
            # SVR with epsilon larger than range of y results in 0 support vectors
            n_samples = rng.randint(4, 10)
            n_features = rng.randint(2, 6)

            # Generate sparse data
            data = rng.uniform(0.1, 1.0)
            row = [rng.randint(0, n_samples - 1) for _ in range(n_samples)]
            col = [rng.randint(0, n_features - 1) for _ in range(n_samples)]
            vals = [rng.uniform(0.1, 2.0) for _ in range(n_samples)]
            X = sp.csr_matrix(
                (vals, (row, col)),
                shape=(n_samples, n_features),
                dtype=np.float64,
            )

            # All y values very close, and epsilon much larger than differences -> 0 SVs
            base_val = rng.uniform(-1.0, 1.0)
            y = np.full(n_samples, base_val, dtype=np.float64)
            # Add tiny noise
            for idx in range(n_samples):
                y[idx] += rng.uniform(-0.01, 0.01)

            epsilon = 1.0  # significantly larger than noise
            C = rng.uniform(1.0, 100.0)

            est = DummyEstimator(
                kernel="linear",
                C=C,
                epsilon=epsilon,
                tol=1e-3,
                max_iter=10000,
                gamma="auto",
            )
            est._sparse_kernels = ["linear", "poly", "rbf", "sigmoid", "precomputed"]
            est._gamma = 1.0 / n_features
            est.class_weight_ = np.empty(0, dtype=np.float64)
            sample_weight = np.ones(n_samples, dtype=np.float64)
            solver_type = 3  # EPSILON_SVR
            kernel = "linear"
            random_seed = rng.randint(0, 10000)

            args = (X, y, sample_weight, solver_type, kernel, random_seed)
            items.append((est, args, {}))

        else:
            # Ordinary case where support vectors exist
            n_samples = rng.randint(5, 15)
            n_features = rng.randint(2, 5)

            density = rng.uniform(0.3, 0.7)
            mat = (
                np.array(
                    [
                        [rng.random() if rng.random() < density else 0.0 for _ in range(n_features)]
                        for _ in range(n_samples)
                    ]
                )
                + 0.01
            )
            X = sp.csr_matrix(mat, dtype=np.float64)

            # Targets with variance to ensure non-empty SVs
            y = np.array(
                [rng.uniform(-5.0, 5.0) for _ in range(n_samples)],
                dtype=np.float64,
            )

            epsilon = rng.uniform(0.001, 0.05)
            C = rng.uniform(0.1, 10.0)

            kernel = rng.choice(["linear", "rbf"])
            est = DummyEstimator(
                kernel=kernel,
                C=C,
                epsilon=epsilon,
                tol=1e-3,
                max_iter=10000,
                gamma="auto",
            )
            est._sparse_kernels = ["linear", "poly", "rbf", "sigmoid", "precomputed"]
            est._gamma = 1.0 / n_features
            est.class_weight_ = np.empty(0, dtype=np.float64)
            sample_weight = np.ones(n_samples, dtype=np.float64)
            solver_type = 3  # EPSILON_SVR
            random_seed = rng.randint(0, 10000)

            args = (X, y, sample_weight, solver_type, kernel, random_seed)
            items.append((est, args, {}))

    return items
