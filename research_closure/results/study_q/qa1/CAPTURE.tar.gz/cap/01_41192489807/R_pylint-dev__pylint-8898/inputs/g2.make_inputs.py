def make_inputs(rng, n):
    items = []

    # Common simple patterns without commas inside regex constructs
    ordinary_patterns = [
        "abc",
        "foo",
        "bar.*",
        r"\d+",
        r"[a-z]+",
        r"^[A-Z_]+$",
        r"test_\w+",
        "",
        "foo,bar",
        "foo, bar, baz",
        r"\w+, [0-9]+",
        r"^([a-z]+)$, ^([0-9]+)$",
    ]

    # Regex patterns containing commas (e.g. quantifiers like {1,3}, character classes [a,b])
    comma_in_regex_patterns = [
        "(foo{1,3})",
        "a{2,4}",
        r"\w{1,}",
        r"\d{0,5}",
        r"[a,b,c]",
        r"^(foo{1,3}|bar{2,4})$",
        r"(foo{1,3}), bar",
        r"bar, (foo{1,3})",
        r"(a{1,2}), (b{2,3})",
        r"foo{1,2}, bar{2,4}, baz{3,5}",
        r"prefix_[a-z]{1,4}_suffix",
        r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]{1,64}\.[a-zA-Z0-9-.]{2,}$",
        r"{1,2}",
        r"a{,2}",
        r"a{2,}",
        r"(a{1,2}, b{3,4})",
    ]

    for i in range(n):
        if i % 2 == 0:
            # Ordinary cases (no internal commas within a regex atom, or simple csv of regexes)
            if rng.random() < 0.3:
                val = rng.choice(ordinary_patterns)
            else:
                count = rng.randint(1, 4)
                parts = [rng.choice(ordinary_patterns[:7]) for _ in range(count)]
                sep = rng.choice([",", ", ", " , "])
                val = sep.join(parts)
        else:
            # Bug/edge cases: regular expressions that contain commas within braces/brackets
            if rng.random() < 0.5:
                val = rng.choice(comma_in_regex_patterns)
            else:
                # Combine ordinary and quantifier/comma-bearing regexes
                count = rng.randint(2, 4)
                parts = [
                    rng.choice(comma_in_regex_patterns + ordinary_patterns)
                    for _ in range(count)
                ]
                sep = rng.choice([",", ", ", " , "])
                val = sep.join(parts)

        items.append((None, (val,), {}))

    return items
