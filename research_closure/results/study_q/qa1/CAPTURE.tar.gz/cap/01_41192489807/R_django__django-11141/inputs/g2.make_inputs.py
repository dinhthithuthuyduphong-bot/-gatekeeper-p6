import sys
import types
from django.apps import apps
from django.conf import settings


def _setup_django():
    if not settings.configured:
        settings.configure(
            INSTALLED_APPS=[],
            MIGRATION_MODULES={},
            DATABASES={"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}},
        )
        apps.populate(settings.INSTALLED_APPS)


_setup_django()


class _DummyAppConfig:
    def __init__(self, label):
        self.label = label


class _DummyMigration:
    def __init__(self, name, app_label):
        self.name = name
        self.app_label = app_label


class _CustomLoader(target_class):
    def __init__(self, app_configs, migration_module_map, ignore_no_migrations=False):
        super().__init__(connection=None, load=False, ignore_no_migrations=ignore_no_migrations)
        self._custom_app_configs = app_configs
        self._custom_migration_modules = migration_module_map

    def migrations_module(self, app_label):
        if app_label in self._custom_migration_modules:
            return self._custom_migration_modules[app_label], True
        return f"{app_label}.migrations", False


def make_inputs(rng, n):
    items = []

    for i in range(n):
        # Determine scenario: namespace package vs regular package vs edge cases
        scenario = rng.choice([
            "namespace_with_migrations",
            "namespace_empty",
            "regular_with_migrations",
            "regular_empty",
            "not_a_package",
            "missing_module",
        ])

        app_label = f"test_app_{i}_{rng.randint(1000, 9999)}"
        module_name = f"dummy_migrations_{i}_{rng.randint(1000, 9999)}"
        ignore_no_migrations = rng.choice([True, False])

        app_config = _DummyAppConfig(app_label)
        migration_modules_map = {app_label: module_name}

        if scenario == "namespace_with_migrations":
            # Namespace package: has __path__, NO __file__
            pkg = types.ModuleType(module_name)
            pkg.__path__ = []  # Empty path for pkgutil
            # inject a migration submodule
            mig_name = "0001_initial"
            mig_mod_name = f"{module_name}.{mig_name}"
            mig_mod = types.ModuleType(mig_mod_name)
            mig_mod.Migration = _DummyMigration
            sys.modules[module_name] = pkg
            sys.modules[mig_mod_name] = mig_mod
            # mock iter_modules to yield the migration
            import pkgutil
            orig_iter = pkgutil.iter_modules

            # To avoid messing pkgutil globally, we can set __path__ and define iter_modules or just hook
            # Alternatively, standard way:
            class DummyFinder:
                pass
            pkg.__path__ = ["dummy_path"]
            # We will patch pkgutil.iter_modules for this module's path:
            loader = _CustomLoader([app_config], migration_modules_map, ignore_no_migrations)

            def make_custom_load_disk(inst, mig_names, is_namespace, has_path):
                old_load_disk = inst.load_disk

                def wrapped_load_disk():
                    orig_apps_get = apps.get_app_configs
                    apps.get_app_configs = lambda: inst._custom_app_configs
                    orig_iter_modules = pkgutil.iter_modules

                    def custom_iter_modules(path=None, prefix=''):
                        if path == pkg.__path__:
                            for name in mig_names:
                                yield (None, name, False)
                        else:
                            yield from orig_iter_modules(path, prefix)

                    pkgutil.iter_modules = custom_iter_modules
                    try:
                        return old_load_disk()
                    finally:
                        apps.get_app_configs = orig_apps_get
                        pkgutil.iter_modules = orig_iter_modules
                        sys.modules.pop(module_name, None)
                        for name in mig_names:
                            sys.modules.pop(f"{module_name}.{name}", None)

                inst.load_disk = wrapped_load_disk
                return inst

            loader = make_custom_load_disk(loader, [mig_name], is_namespace=True, has_path=True)
            items.append((loader, (), {}))

        elif scenario == "namespace_empty":
            # Namespace package without migrations
            pkg = types.ModuleType(module_name)
            pkg.__path__ = ["dummy_namespace_path"]
            sys.modules[module_name] = pkg

            loader = _CustomLoader([app_config], migration_modules_map, ignore_no_migrations)

            def make_custom_load_disk(inst):
                old_load_disk = inst.load_disk

                def wrapped_load_disk():
                    orig_apps_get = apps.get_app_configs
                    apps.get_app_configs = lambda: inst._custom_app_configs
                    orig_iter_modules = pkgutil.iter_modules
                    pkgutil.iter_modules = lambda path=None, prefix='': [] if path == pkg.__path__ else orig_iter_modules(path, prefix)
                    try:
                        return old_load_disk()
                    finally:
                        apps.get_app_configs = orig_apps_get
                        pkgutil.iter_modules = orig_iter_modules
                        sys.modules.pop(module_name, None)

                inst.load_disk = wrapped_load_disk
                return inst

            loader = make_custom_load_disk(loader)
            items.append((loader, (), {}))

        elif scenario == "regular_with_migrations":
            # Regular package: has __file__ and __path__
            pkg = types.ModuleType(module_name)
            pkg.__file__ = f"/path/to/{module_name}/__init__.py"
            pkg.__path__ = [f"/path/to/{module_name}"]
            mig_name = f"000{rng.randint(1, 9)}_auto"
            mig_mod_name = f"{module_name}.{mig_name}"
            mig_mod = types.ModuleType(mig_mod_name)
            mig_mod.Migration = _DummyMigration
            sys.modules[module_name] = pkg
            sys.modules[mig_mod_name] = mig_mod

            loader = _CustomLoader([app_config], migration_modules_map, ignore_no_migrations)

            def make_custom_load_disk(inst, mig_names):
                old_load_disk = inst.load_disk

                def wrapped_load_disk():
                    orig_apps_get = apps.get_app_configs
                    apps.get_app_configs = lambda: inst._custom_app_configs
                    orig_iter_modules = pkgutil.iter_modules

                    def custom_iter_modules(path=None, prefix=''):
                        if path == pkg.__path__:
                            for name in mig_names:
                                yield (None, name, False)
                        else:
                            yield from orig_iter_modules(path, prefix)

                    pkgutil.iter_modules = custom_iter_modules
                    try:
                        return old_load_disk()
                    finally:
                        apps.get_app_configs = orig_apps_get
                        pkgutil.iter_modules = orig_iter_modules
                        sys.modules.pop(module_name, None)
                        for name in mig_names:
                            sys.modules.pop(f"{module_name}.{name}", None)

                inst.load_disk = wrapped_load_disk
                return inst

            loader = make_custom_load_disk(loader, [mig_name])
            items.append((loader, (), {}))

        elif scenario == "regular_empty":
            pkg = types.ModuleType(module_name)
            pkg.__file__ = f"/path/to/{module_name}/__init__.py"
            pkg.__path__ = [f"/path/to/{module_name}"]
            sys.modules[module_name] = pkg

            loader = _CustomLoader([app_config], migration_modules_map, ignore_no_migrations)

            def make_custom_load_disk(inst):
                old_load_disk = inst.load_disk

                def wrapped_load_disk():
                    orig_apps_get = apps.get_app_configs
                    apps.get_app_configs = lambda: inst._custom_app_configs
                    orig_iter_modules = pkgutil.iter_modules
                    pkgutil.iter_modules = lambda path=None, prefix='': [] if path == pkg.__path__ else orig_iter_modules(path, prefix)
                    try:
                        return old_load_disk()
                    finally:
                        apps.get_app_configs = orig_apps_get
                        pkgutil.iter_modules = orig_iter_modules
                        sys.modules.pop(module_name, None)

                inst.load_disk = wrapped_load_disk
                return inst

            loader = make_custom_load_disk(loader)
            items.append((loader, (), {}))

        elif scenario == "not_a_package":
            # Module without __path__ (e.g. migrations.py)
            pkg = types.ModuleType(module_name)
            pkg.__file__ = f"/path/to/{module_name}.py"
            sys.modules[module_name] = pkg

            loader = _CustomLoader([app_config], migration_modules_map, ignore_no_migrations)

            def make_custom_load_disk(inst):
                old_load_disk = inst.load_disk

                def wrapped_load_disk():
                    orig_apps_get = apps.get_app_configs
                    apps.get_app_configs = lambda: inst._custom_app_configs
                    try:
                        return old_load_disk()
                    finally:
                        apps.get_app_configs = orig_apps_get
                        sys.modules.pop(module_name, None)

                inst.load_disk = wrapped_load_disk
                return inst

            loader = make_custom_load_disk(loader)
            items.append((loader, (), {}))

        else:  # missing_module
            loader = _CustomLoader([app_config], migration_modules_map, ignore_no_migrations=True)

            def make_custom_load_disk(inst):
                old_load_disk = inst.load_disk

                def wrapped_load_disk():
                    orig_apps_get = apps.get_app_configs
                    apps.get_app_configs = lambda: inst._custom_app_configs
                    try:
                        return old_load_disk()
                    finally:
                        apps.get_app_configs = orig_apps_get

                inst.load_disk = wrapped_load_disk
                return inst

            loader = make_custom_load_disk(loader)
            items.append((loader, (), {}))

    return items
