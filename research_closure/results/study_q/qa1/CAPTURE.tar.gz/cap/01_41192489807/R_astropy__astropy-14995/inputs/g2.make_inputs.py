import numpy as np
from astropy.nddata import NDDataRef


def make_inputs(rng, n):
    items = []

    def make_mask(shape, dtype):
        if dtype == "bool":
            return np.array(
                [rng.choice([True, False]) for _ in range(np.prod(shape))]
            ).reshape(shape)
        elif dtype == "int":
            return np.array(
                [rng.choice([0, 1, 2, 4, 8, 16, 64]) for _ in range(np.prod(shape))]
            ).reshape(shape)
        return None

    handle_mask_choices = [
        np.bitwise_or,
        np.bitwise_and,
        np.bitwise_xor,
        np.logical_or,
        np.logical_and,
        np.logical_xor,
    ]

    for i in range(n):
        shape = (rng.randint(1, 4), rng.randint(1, 4))
        # Decide scenario
        # Even indices / second half target the issue: self has mask, operand does not (operand.mask is None)
        if i % 2 == 0:
            scenario = "self_mask_operand_nomask"
        else:
            scenario = rng.choice(
                [
                    "both_masks",
                    "neither_mask",
                    "operand_mask_self_nomask",
                    "handle_mask_none",
                ]
            )

        data1 = np.ones(shape)
        data2 = np.ones(shape)

        dtype_choice = rng.choice(["bool", "int"])

        if scenario == "self_mask_operand_nomask":
            mask1 = make_mask(shape, dtype_choice)
            mask2 = None
            handle_mask = rng.choice(handle_mask_choices)
        elif scenario == "both_masks":
            mask1 = make_mask(shape, dtype_choice)
            mask2 = make_mask(shape, dtype_choice)
            handle_mask = rng.choice(handle_mask_choices)
        elif scenario == "neither_mask":
            mask1 = None
            mask2 = None
            handle_mask = rng.choice(handle_mask_choices)
        elif scenario == "operand_mask_self_nomask":
            mask1 = None
            mask2 = make_mask(shape, dtype_choice)
            handle_mask = rng.choice(handle_mask_choices)
        elif scenario == "handle_mask_none":
            mask1 = (
                make_mask(shape, dtype_choice) if rng.choice([True, False]) else None
            )
            mask2 = (
                make_mask(shape, dtype_choice) if rng.choice([True, False]) else None
            )
            handle_mask = None

        receiver = NDDataRef(data1, mask=mask1)
        operand = NDDataRef(data2, mask=mask2)
        operation = np.add

        args = (operation, operand, handle_mask)
        kwargs = {}

        items.append((receiver, args, kwargs))

    return items
