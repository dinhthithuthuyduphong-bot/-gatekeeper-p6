def make_inputs(rng, n):
    import sympy
    from sympy import Function, Symbol, Wild, Dummy

    classes = [Function, Symbol, Wild, Dummy]

    def random_name(depth=0):
        if depth > 2 or rng.random() < 0.6:
            choice = rng.choice(['single', 'range_num', 'range_alpha', 'list_str'])
            if choice == 'single':
                return rng.choice(['x', 'y', 'z', 'q', 'u', 'alpha', 'beta', 'f', 'g'])
            elif choice == 'range_num':
                var = rng.choice(['x', 'y', 'q', 'u'])
                high = rng.randint(1, 4)
                return f"{var}:{high}"
            elif choice == 'range_alpha':
                return rng.choice(['a:c', 'x:z', 'i:l'])
            else:
                return rng.choice(['x, y', 'f g', 'a:c, x:z', 'q:2, u:2'])
        else:
            container = rng.choice([tuple, list])
            count = rng.randint(1, 3)
            return container(random_name(depth + 1) for _ in range(count))

    items = []
    for i in range(n):
        # Half ordinary, half targeting nested structures with custom cls
        if i % 2 == 0:
            # Bug-triggering: nested sequences (tuple, list) with cls != Symbol (often Function)
            cls_choice = rng.choice([Function, Wild, Dummy])
            container = rng.choice([tuple, list])
            count = rng.randint(1, 3)
            names = container(
                rng.choice([
                    f"{rng.choice(['q', 'u', 'f', 'g'])}:{rng.randint(1, 4)}",
                    rng.choice(['a:c', 'x:z']),
                    rng.choice(['f', 'g', 'h']),
                    (f"x:{rng.randint(1, 3)}", f"y:{rng.randint(1, 3)}") if rng.random() < 0.3 else 'z'
                ]) for _ in range(count)
            )
            kwargs = {'cls': cls_choice}
            if rng.random() < 0.3:
                kwargs['real'] = rng.choice([True, False])
            items.append((None, (names,), kwargs))
        else:
            # Ordinary usage
            cls_choice = rng.choice(classes) if rng.random() < 0.3 else Symbol
            names = random_name(depth=0)
            kwargs = {}
            if cls_choice is not Symbol:
                kwargs['cls'] = cls_choice
            if rng.random() < 0.3:
                kwargs['commutative'] = rng.choice([True, False])
            if rng.random() < 0.3:
                kwargs['integer'] = rng.choice([True, False])
            if rng.random() < 0.2 and isinstance(names, str):
                kwargs['seq'] = rng.choice([True, False])
            items.append((None, (names,), kwargs))

    return items
