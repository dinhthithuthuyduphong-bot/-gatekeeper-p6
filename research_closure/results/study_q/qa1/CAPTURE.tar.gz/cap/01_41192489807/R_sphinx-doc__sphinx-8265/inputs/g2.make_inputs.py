def make_inputs(rng, n):
    import ast

    # In Python < 3.11, starred expressions in subscript slices are a SyntaxError.
    # Therefore, construct valid ASTs for all Python 3 versions.
    tuple_subscripts = [
        "a[x, y]",
        "Dict[int, str]",
        "Callable[[int, str], None]",
        "Union[int, str, float]",
        "a[1, 2, 3]",
        "arr[i, :]",
        "arr[:, j]",
        "a[(x, y)]",
        "a[()]",
        "Tuple[int, ...]",
        "a[1, (2, 3)]",
        "a[(1, 2), 3]",
        "T[a, b, c, d]",
        "a[x, y, z]",
        "grid[0, 1, 2]",
    ]

    # Dynamically create an AST with Starred in tuple slice to test that edge case safely
    def make_starred_subscript():
        starred_tup = ast.Tuple(
            elts=[ast.Name(id='x', ctx=ast.Load()), ast.Starred(value=ast.Name(id='y', ctx=ast.Load()), ctx=ast.Load())],
            ctx=ast.Load()
        )
        try:
            # Python < 3.9 uses ast.Index wrapper
            sl = ast.Index(value=starred_tup)
        except AttributeError:
            sl = starred_tup
        return ast.Subscript(
            value=ast.Name(id='a', ctx=ast.Load()),
            slice=sl,
            ctx=ast.Load()
        )

    simple_subscripts = [
        "a[0]",
        "a[-1]",
        "a[x]",
        "a['key']",
        "a[None]",
        "a[True]",
        "a[1 + 2]",
        "a[f(x)]",
        "a[:]",
        "a[1:2]",
        "a[1:10:2]",
        "a[::2]",
        "a[1:]",
        "a[:5]",
        "a[b[0]]",
        "List[int]",
        "Optional[str]",
    ]

    items = []
    for i in range(n):
        visitor = target_class() if target_class else module._UnparseVisitor()
        if i % 2 == 0:
            if rng.random() < 0.1:
                node = make_starred_subscript()
            else:
                expr_str = rng.choice(tuple_subscripts)
                tree = ast.parse(expr_str)
                node = next(n for n in ast.walk(tree) if isinstance(n, ast.Subscript))
        else:
            expr_str = rng.choice(simple_subscripts)
            tree = ast.parse(expr_str)
            node = next(n for n in ast.walk(tree) if isinstance(n, ast.Subscript))

        items.append((visitor, (node,), {}))

    return items
