import typing

def make_inputs(rng, n):
    items = []
    
    # Pre-generate some TypeVar instances and types for edge-case inputs
    T = typing.TypeVar('T')
    KT = typing.TypeVar('KT')
    VT = typing.TypeVar('VT')
    
    non_str_keys = [
        T,
        KT,
        VT,
        int,
        str,
        typing.List[int],
        typing.Union[int, str],
        typing.Tuple[T, ...],
        typing.Generic[T],
        (int, str),
        (T, VT),
        123,
        45.67,
        True,
        None,
        object(),
        [1, 2],
        {'a': 1},
    ]

    str_keys = [
        "T",
        "item",
        "Key",
        "value",
        "__name__",
        "submodule.ClassName",
        "a",
        "",
        "foo_bar_123",
        "List[int]",
        "Union[A, B]",
    ]

    for i in range(n):
        # Create an instance of _MockObject or a subclass with varied __display_name__
        receiver = target_class()
        if rng.random() < 0.5:
            display_name = rng.choice(["module", "package.SubClass", "GenericClass", "_MockObject", "MyMock"])
            receiver.__display_name__ = display_name
            # Also occasionally set class display name as mock does
            receiver.__class__.__display_name__ = display_name

        if i < n // 2:
            # Ordinary string keys
            key = rng.choice(str_keys)
            if rng.random() < 0.2:
                # generate random alphanumeric string
                key = "".join(rng.choices("abcdefghijklmnopqrstuvwxyz_0123456789", k=rng.randint(1, 10)))
        else:
            # Non-string keys, specifically TypeVar, types, tuples of TypeVars, etc.
            key = rng.choice(non_str_keys)
        
        args = (key,)
        kwargs = {}
        items.append((receiver, args, kwargs))

    return items
