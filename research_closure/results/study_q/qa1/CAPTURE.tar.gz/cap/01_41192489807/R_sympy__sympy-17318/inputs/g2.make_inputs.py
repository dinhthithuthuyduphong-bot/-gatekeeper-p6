def make_inputs(rng, n):
    from sympy import S, I, sqrt, Rational

    items = []
    surds = [sqrt(2), sqrt(3), sqrt(5), sqrt(6), sqrt(7), 2 * sqrt(2), 3 * sqrt(3)]

    for i in range(n):
        if i % 2 == 0:
            # Bug/edge cases: Add whose terms square to rationals, but some are <= 0 (e.g. imaginary or zero)
            # or mixed with imaginary terms where x**2 is Rational but not positive Rational.
            choice = rng.choice([1, 2, 3, 4, 5])
            if choice == 1:
                # Direct bug trigger: terms containing I whose squares are negative rationals
                coeff = rng.choice([1, 2, 3, -1, -2, -3])
                expr = rng.choice([1, 2, 3, -1]) * I + rng.choice([1, 2, 3])
                items.append((None, (expr,), {}))
            elif choice == 2:
                # Add with real surds and pure imaginary surds, e.g., sqrt(2) + I
                r1 = rng.choice(surds)
                im_term = rng.choice([I, 2 * I, -I, 3 * I, I * sqrt(2), I * sqrt(3)])
                const = rng.choice([0, 1, -2, 3])
                expr = const + r1 + im_term
                items.append((None, (expr,), {}))
            elif choice == 3:
                # Multiple purely imaginary terms that square to negative rationals
                expr = rng.choice([1, 2, -1]) * I * sqrt(2) + rng.choice([1, -1]) * I * sqrt(3)
                if rng.random() < 0.5:
                    expr += rng.choice([1, -2, 3])
                items.append((None, (expr,), {}))
            elif choice == 4:
                # A single imaginary term with a rational
                c = Rational(rng.randint(-5, 5), rng.randint(1, 4))
                expr = c + rng.choice([1, -1, 2, -2]) * I
                items.append((None, (expr,), {}))
            else:
                # Expression from the issue report or variants
                nested = sqrt(rng.choice([2, 3, 5])) * sqrt(rng.choice([2, 3, 4]) + rng.choice([1, 2, 3]) * I)
                expr = rng.choice([1, 2, 3]) + rng.choice([1, -1]) * nested + rng.choice([1, 2, 3]) * I
                items.append((None, (expr,), {}))
        else:
            # Ordinary cases: all square terms are positive rationals, or general surd matching
            choice = rng.choice([1, 2, 3, 4, 5])
            if choice == 1:
                # Pure positive surds (split_surds valid)
                s1 = rng.choice(surds)
                s2 = rng.choice(surds)
                expr = rng.choice([0, 1, 2, -1]) + s1 + s2
                items.append((None, (expr,), {}))
            elif choice == 2:
                # Numbers
                expr = Rational(rng.randint(-10, 10), rng.randint(1, 5))
                items.append((None, (expr,), {}))
            elif choice == 3:
                # Single term / Mul
                expr = rng.choice([1, -1, 2, -2]) * rng.choice(surds)
                items.append((None, (expr,), {}))
            elif choice == 4:
                # Nested square roots with depth > 1
                inner = rng.choice([2, 3, 5]) + rng.choice(surds)
                expr = rng.choice([1, 2]) + sqrt(inner)
                items.append((None, (expr,), {}))
            else:
                # 3 surds sum
                expr = sqrt(2) + sqrt(3) + sqrt(5) + rng.choice([-1, 0, 1])
                items.append((None, (expr,), {}))

    return items
