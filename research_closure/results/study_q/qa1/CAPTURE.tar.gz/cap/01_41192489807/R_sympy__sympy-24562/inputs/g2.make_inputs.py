def make_inputs(rng, n):
    cls = target_class
    items = []

    def rand_int_str():
        val = rng.randint(-100, 100)
        return str(val)

    def rand_decimal_str():
        sign = "-" if rng.random() < 0.3 else ""
        int_part = rng.randint(0, 50)
        dec_part = rng.randint(1, 99)
        return f"{sign}{int_part}.{dec_part}"

    def rand_fraction_str():
        num = rng.randint(-50, 50)
        den = rng.choice([d for d in range(-50, 51) if d != 0])
        return f"{num}/{den}"

    def rand_float():
        return rng.choice([-2.5, -0.5, -0.25, 0.0, 0.1, 0.5, 1.25, 2.0, 10.5])

    for i in range(n):
        # Around half ordinary, half targeting string/non-integer pairs where p or q are non-SYMPY_INTS
        if i % 2 == 0:
            # Bug-triggering cases: non-integer p or q passed with a second argument q
            # In the buggy code: `q *= p.q; ... q = q.p` overwrote q instead of accumulating
            mode = rng.randint(0, 4)
            if mode == 0:
                p = rand_decimal_str()
                q = rand_int_str() if rng.random() < 0.7 else str(rng.randint(1, 100))
            elif mode == 1:
                p = rand_decimal_str()
                q = rand_decimal_str()
            elif mode == 2:
                p = rand_fraction_str()
                q = rand_int_str()
            elif mode == 3:
                p = rand_float()
                q = rand_int_str()
            else:
                p = rand_int_str()
                q = rand_fraction_str()
            items.append((None, (cls, p, q), {}))
        else:
            # Ordinary cases
            sub = rng.randint(0, 4)
            if sub == 0:
                # p, q as standard ints
                p = rng.randint(-100, 100)
                q = rng.choice([x for x in range(-100, 101) if x != 0])
                items.append((None, (cls, p, q), {}))
            elif sub == 1:
                # single integer / float
                p = rng.choice([rng.randint(-100, 100), rand_float()])
                items.append((None, (cls, p), {}))
            elif sub == 2:
                # single string: int, decimal, or fraction
                choice = rng.choice([rand_int_str, rand_decimal_str, rand_fraction_str])
                items.append((None, (cls, choice()), {}))
            elif sub == 3:
                # p and q as ints with gcd specified
                p = rng.randint(-50, 50)
                q = rng.choice([x for x in range(-50, 51) if x != 0])
                gcd = 1 if rng.random() < 0.5 else None
                items.append((None, (cls, p, q, gcd), {}))
            else:
                # Exact issue example or variations
                p, q = rng.choice([
                    ('0.5', '100'),
                    ('0.5', 100),
                    ('1.5', '10'),
                    ('0.25', '4'),
                    ('0.1', '10'),
                    ('-0.5', '100'),
                ])
                items.append((None, (cls, p, q), {}))

    return items
