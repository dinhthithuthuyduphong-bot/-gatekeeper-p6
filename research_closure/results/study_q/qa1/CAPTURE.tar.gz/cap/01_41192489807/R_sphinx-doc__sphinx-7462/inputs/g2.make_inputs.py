def make_inputs(rng, n):
    normal_types = [
        "int",
        "str",
        "None",
        "List[int]",
        "Dict[str, int]",
        "Tuple[int, str]",
        "typing.Union[int, str]",
        "typing.Optional[str]",
        "a.b.c.Foo",
        "Callable[[int, str], None]",
        "Tuple[int]",
        "List[Tuple[int, str]]",
        "Dict[str, Tuple[int, int]]",
        "typing.Any",
        "Set[int]",
    ]

    issue_types = [
        "Tuple[()]",
        "()",
        "typing.Tuple[()]",
        "Union[Tuple[()], int]",
        "List[Tuple[()]]",
        "Dict[Tuple[()], Tuple[()]]",
        "Tuple[(), ()]",
        "Callable[[Tuple[()]], None]",
        "Tuple[(), int]",
        "Tuple[int, ()]",
        "typing.Tuple[(), ...]",
        "Tuple[Tuple[()]]",
        "Optional[Tuple[()]]",
    ]

    items = []
    for _ in range(n):
        if rng.random() < 0.5:
            # Bug/edge-case related inputs: empty tuples, nested empty tuples
            ann = rng.choice(issue_types)
        else:
            # Normal type annotation inputs
            ann = rng.choice(normal_types)
        items.append((None, (ann,), {}))

    return items
