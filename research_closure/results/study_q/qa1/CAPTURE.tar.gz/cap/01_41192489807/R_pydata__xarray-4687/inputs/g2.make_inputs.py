def make_inputs(rng, n):
    import numpy as np
    import xarray as xr

    items = []

    def make_random_da(dims_shapes, with_attrs=False, dtype=int):
        dims = list(dims_shapes.keys())
        shape = tuple(dims_shapes.values())
        total_size = 1
        for s in shape:
            total_size *= s

        if dtype == bool:
            raw = [rng.choice([True, False]) for _ in range(total_size)]
            data = np.array(raw, dtype=bool).reshape(shape)
        elif dtype == float:
            raw = [rng.uniform(-10.0, 10.0) for _ in range(total_size)]
            data = np.array(raw, dtype=float).reshape(shape)
        else:
            raw = [rng.randint(-10, 10) for _ in range(total_size)]
            data = np.array(raw, dtype=int).reshape(shape)

        da = xr.DataArray(data, dims=dims)
        if with_attrs:
            num_attrs = rng.randint(1, 4)
            for _ in range(num_attrs):
                da.attrs[f"attr_{rng.randint(1, 100)}"] = rng.choice(
                    ["val", 42, 3.14, True]
                )
        return da

    for i in range(n):
        is_attrs_case = i % 2 == 1
        case_type = rng.choice(["1d", "2d", "scalar", "dataset"])

        if case_type == "scalar":
            cond = rng.choice([True, False])
            x = rng.randint(-10, 10)
            y = rng.randint(-10, 10)
            kwargs = {}
            if is_attrs_case:
                kw_val = rng.choice([True, False, None])
                if kw_val is not None or rng.choice([True, False]):
                    kwargs["keep_attrs"] = kw_val
            items.append((None, (cond, x, y), kwargs))
            continue

        if case_type == "dataset":
            da_x = make_random_da(
                {"x": 3}, with_attrs=is_attrs_case, dtype=float
            )
            da_y = make_random_da({"x": 3}, with_attrs=is_attrs_case, dtype=int)
            ds_x = xr.Dataset({"var": da_x})
            ds_y = xr.Dataset({"var": da_y})
            if is_attrs_case:
                ds_x.attrs["ds_attr"] = "x_attr"
                ds_y.attrs["ds_attr"] = "y_attr"
            cond = xr.DataArray(
                np.array([True, False, True], dtype=bool), dims=["x"]
            )
            kwargs = {}
            if is_attrs_case and rng.choice([True, False]):
                kwargs["keep_attrs"] = rng.choice([True, False, None])
            items.append((None, (cond, ds_x, ds_y), kwargs))
            continue

        dims = {"dim0": 4} if case_type == "1d" else {"dim0": 3, "dim1": 2}
        cond = make_random_da(dims, dtype=bool)

        x_kind = rng.choice(["da", "scalar"])
        y_kind = rng.choice(["da", "scalar"])

        x = (
            make_random_da(dims, with_attrs=is_attrs_case, dtype=float)
            if x_kind == "da"
            else rng.randint(-5, 5)
        )
        y = (
            make_random_da(dims, with_attrs=is_attrs_case, dtype=int)
            if y_kind == "da"
            else rng.randint(-5, 5)
        )

        kwargs = {}
        if is_attrs_case:
            choice = rng.choice(["none", "true", "false", "custom", "omitted"])
            if choice == "none":
                kwargs["keep_attrs"] = None
            elif choice == "true":
                kwargs["keep_attrs"] = True
            elif choice == "false":
                kwargs["keep_attrs"] = False
            elif choice == "custom":
                kwargs["keep_attrs"] = lambda attrs, context=None: {
                    "merged": True
                }

        items.append((None, (cond, x, y), kwargs))

    return items
