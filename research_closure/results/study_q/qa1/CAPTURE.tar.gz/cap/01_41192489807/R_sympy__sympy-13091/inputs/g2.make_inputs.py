def make_inputs(rng, n):
    import sympy
    from sympy import Symbol, Integer, Rational, Pow, Add, Mul, Float

    Basic = module.Basic

    class CustomObject:
        def __init__(self, val):
            self.val = val

        def __eq__(self, other):
            if isinstance(other, Basic):
                return self.val == other
            return NotImplemented

    class UnknownType:
        pass

    class CantSympify:
        def __iter__(self):
            raise TypeError("Not iterable")

    symbols = [Symbol('x'), Symbol('y'), Symbol('z'), Symbol('a'), Symbol('b')]
    integers = [Integer(0), Integer(1), Integer(2), Integer(-1)]
    rationals = [Rational(1, 2), Rational(3, 4), Rational(-2, 3)]
    floats = [Float(1.0), Float(0.0), Float(2.5)]

    def make_random_basic(depth=0):
        if depth > 1 or rng.random() < 0.6:
            pool = symbols + integers + rationals + floats
            return rng.choice(pool)
        choice = rng.choice(['add', 'mul', 'pow'])
        if choice == 'add':
            return Add(make_random_basic(depth + 1), make_random_basic(depth + 1))
        elif choice == 'mul':
            return Mul(make_random_basic(depth + 1), make_random_basic(depth + 1))
        else:
            return Pow(make_random_basic(depth + 1), rng.choice([Integer(1), Integer(2), Integer(-1)]))

    items = []
    for _ in range(n):
        receiver = make_random_basic()

        if rng.random() < 0.5:
            # Issue-related: comparing with objects that raise SympifyError when _sympified
            choice = rng.choice(['custom', 'unknown', 'cant_sympify', 'dict', 'set', 'func', 'object'])
            if choice == 'custom':
                arg = CustomObject(receiver if rng.random() < 0.5 else make_random_basic())
            elif choice == 'unknown':
                arg = UnknownType()
            elif choice == 'cant_sympify':
                arg = CantSympify()
            elif choice == 'dict':
                arg = {'a': 1, 'b': receiver}
            elif choice == 'set':
                arg = {1, 2, receiver}
            elif choice == 'func':
                arg = lambda x: x
            else:
                arg = object()
        else:
            # Standard Basic comparisons
            sub_choice = rng.choice(['same', 'basic', 'pow_1', 'int', 'float', 'str', 'tuple', 'list'])
            if sub_choice == 'same':
                arg = receiver
            elif sub_choice == 'basic':
                arg = make_random_basic()
            elif sub_choice == 'pow_1':
                arg = Pow(receiver, Integer(1))
            elif sub_choice == 'int':
                arg = rng.choice([0, 1, 2, -1, 10])
            elif sub_choice == 'float':
                arg = rng.choice([0.0, 1.0, 2.5, -1.0])
            elif sub_choice == 'str':
                arg = rng.choice(['x', 'y', '1', 'sin(x)', 'unknown_str'])
            elif sub_choice == 'tuple':
                arg = (1, 2)
            else:
                arg = [1, 2]

        items.append((receiver, (arg,), {}))

    return items
