from unittest.mock import MagicMock


def make_inputs(rng, n):
    items = []

    builder_names = [
        "html",
        "dirhtml",
        "singlehtml",
        "epub",
        "epub3",
        "latex",
        "text",
    ]

    for i in range(n):
        # Determine builder and config settings
        # Focus roughly half the cases on epub / singlehtml variants
        is_target_case = (i % 2 == 0)

        if is_target_case:
            builder_name = rng.choice(["singlehtml", "epub", "epub3"])
            viewcode_enable_epub = rng.choice([False, True])
        else:
            builder_name = rng.choice(["html", "dirhtml", "text", "latex"])
            viewcode_enable_epub = rng.choice([False, True])

        # Create mock application structure
        app = MagicMock()
        app.verbosity = 0
        app.builder.name = builder_name
        app.builder.get_relative_uri.side_effect = (
            lambda from_page, to_page: f"{from_page}_to_{to_page}"
        )

        class MockHighlighter:
            def highlight_block(self, code, lexer, linenos=False):
                return f"<pre>{code}</pre>"

        app.builder.highlighter = MockHighlighter()

        # Build environment and config
        env = MagicMock()
        env.config.viewcode_enable_epub = viewcode_enable_epub
        env.config.highlight_language = rng.choice(["default", "python3", "none", "python"])
        env.config.viewcode_follow_imported_members = rng.choice([True, False])

        # Decide whether to have modules or not
        has_modules = rng.random() > 0.1
        if not has_modules:
            if hasattr(env, "_viewcode_modules"):
                del env._viewcode_modules
        else:
            modules = {}
            num_mods = rng.randint(1, 3)
            possible_names = [
                "pkg",
                "pkg.mod",
                "pkg.mod.submod",
                "other",
                "other.tool",
            ]
            chosen_names = rng.sample(possible_names, min(num_mods, len(possible_names)))

            for modname in chosen_names:
                code = "def foo():\n    pass\n"
                tags = {"foo": ("def", 1, 1)}
                used = {"foo": "index"} if rng.choice([True, False]) else {}
                refname = modname
                modules[modname] = (code, tags, used, refname)

            env._viewcode_modules = modules

        app.builder.env = env
        items.append((None, (app,), {}))

    return items
