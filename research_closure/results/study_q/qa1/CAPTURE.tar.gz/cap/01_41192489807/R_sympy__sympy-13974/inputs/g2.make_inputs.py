def make_inputs(rng, n):
    from sympy import Symbol, S, Integer
    from sympy.physics.quantum import TensorProduct, Commutator, AntiCommutator

    A = Symbol('A', commutative=False)
    B = Symbol('B', commutative=False)
    C = Symbol('C', commutative=False)
    D = Symbol('D', commutative=False)
    X = Symbol('X', commutative=False)
    Y = Symbol('Y', commutative=False)
    nc_symbols = [A, B, C, D, X, Y]
    c_scalars = [Integer(1), Integer(2), Integer(-1), Symbol('k'), Symbol('x')]

    def random_tp(dim=2):
        ops = [rng.choice(nc_symbols + c_scalars) for _ in range(dim)]
        # Ensure at least one nc symbol so it doesn't reduce away unexpectedly
        if all(op in c_scalars for op in ops):
            ops[rng.randrange(dim)] = rng.choice(nc_symbols)
        return TensorProduct(*ops)

    def make_pow_case():
        dim = rng.choice([2, 3])
        tp1 = random_tp(dim)
        exp = rng.choice([2, 3, 4, Symbol('n')])
        case_type = rng.choice(['simple_pow', 'mul_pow', 'pow_mul_pow', 'add_pow', 'scalar_mul_pow'])

        if case_type == 'simple_pow':
            return tp1 ** exp
        elif case_type == 'scalar_mul_pow':
            c = rng.choice(c_scalars)
            return c * (tp1 ** exp)
        elif case_type == 'mul_pow':
            tp2 = random_tp(dim)
            if rng.random() < 0.5:
                return (tp1 ** exp) * tp2
            else:
                return tp2 * (tp1 ** exp)
        elif case_type == 'pow_mul_pow':
            tp2 = random_tp(dim)
            exp2 = rng.choice([2, 3])
            return (tp1 ** exp) * (tp2 ** exp2)
        else: # add_pow
            tp2 = random_tp(dim)
            return (tp1 ** exp) + (tp2 ** 2)

    def make_ordinary_case():
        dim = rng.choice([2, 3])
        case_type = rng.choice(['single_tp', 'mul_tp', 'add_tp', 'comm_tp', 'anticomm_tp', 'plain_expr'])

        if case_type == 'single_tp':
            return random_tp(dim)
        elif case_type == 'mul_tp':
            num_factors = rng.choice([2, 3])
            c = rng.choice(c_scalars) if rng.random() < 0.5 else 1
            res = c
            for _ in range(num_factors):
                res = res * random_tp(dim)
            return res
        elif case_type == 'add_tp':
            tp1 = random_tp(dim)
            tp2 = random_tp(dim)
            return tp1 + tp2
        elif case_type == 'comm_tp':
            tp1 = random_tp(dim)
            tp2 = random_tp(dim)
            return Commutator(tp1, tp2)
        elif case_type == 'anticomm_tp':
            tp1 = random_tp(dim)
            tp2 = random_tp(dim)
            return AntiCommutator(tp1, tp2)
        else:
            return rng.choice(nc_symbols) * rng.choice(c_scalars)

    items = []
    half = n // 2
    for i in range(n):
        if i < half:
            expr = make_pow_case()
        else:
            expr = make_ordinary_case()
        items.append((None, (expr,), {}))

    return items
