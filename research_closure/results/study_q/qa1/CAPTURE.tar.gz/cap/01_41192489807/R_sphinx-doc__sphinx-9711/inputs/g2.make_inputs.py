def make_inputs(rng, n):
    class MockApp:
        def __init__(self, extensions):
            self.extensions = extensions

    class MockConfig:
        def __init__(self, needs_extensions):
            self.needs_extensions = needs_extensions

    Extension = module.Extension

    version_samples_numeric = [
        ("0.6", "0.10"),
        ("0.6.0", "0.10.0"),
        ("1.9", "1.10"),
        ("1.2", "1.10.1"),
        ("0.9.1", "0.10"),
        ("0.2", "0.11"),
        ("2.0.8", "2.0.10"),
        ("1.10", "1.9"),
        ("1.0", "1.0"),
        ("2.1.0", "2.1.0"),
        ("0.1.2", "0.1.1"),
        ("1.0a2", "1.0b1"),
        ("1.0.dev1", "1.0.0"),
    ]

    version_samples_general = [
        ("1.0", "1.0"),
        ("1.0", "2.0"),
        ("2.0", "1.0"),
        ("1.2.3", "1.2.4"),
        ("1.5", "1.5.0"),
        ("foo-1.0", "foo-2.0"),
        ("custom_v1", "custom_v2"),
        ("unknown version", "1.0"),
        ("1.0", "unknown version"),
    ]

    items = []
    for i in range(n):
        # Decide scenario
        if i % 10 == 0:
            # config.needs_extensions is None
            app = MockApp({})
            config = MockConfig(None)
            items.append((None, (app, config), {}))
            continue

        if i % 10 == 1:
            # Extension not loaded
            app = MockApp({})
            config = MockConfig({"missing_ext": "1.0"})
            items.append((None, (app, config), {}))
            continue

        is_version_tricky = (i % 2 == 0)

        extensions = {}
        needs_extensions = {}

        num_exts = rng.randint(1, 3)
        for idx in range(num_exts):
            ext_name = f"ext_{idx}"
            if is_version_tricky:
                req_ver, act_ver = rng.choice(version_samples_numeric)
                # optionally swap to test opposite direction
                if rng.random() < 0.3:
                    req_ver, act_ver = act_ver, req_ver
            else:
                req_ver, act_ver = rng.choice(version_samples_general)

            needs_extensions[ext_name] = req_ver
            if act_ver == "unknown version":
                ext_obj = Extension(ext_name, None)
            else:
                ext_obj = Extension(ext_name, None, version=act_ver)
            extensions[ext_name] = ext_obj

        app = MockApp(extensions)
        config = MockConfig(needs_extensions)
        items.append((None, (app, config), {}))

    return items
