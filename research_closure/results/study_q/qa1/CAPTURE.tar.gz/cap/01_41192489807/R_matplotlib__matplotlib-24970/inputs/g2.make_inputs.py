import numpy as np


def make_inputs(rng, n):
    items = []
    cmaps = [
        module.ListedColormap([[0, 0, 0, 1], [1, 1, 1, 1]], name="test2", N=2),
        module.ListedColormap(
            np.linspace(0, 1, 4 * 10).reshape(10, 4), name="test10", N=10
        ),
        module.ListedColormap(
            np.linspace(0, 1, 4 * 256).reshape(256, 4), name="test256", N=256
        ),
    ]

    for i in range(n):
        cmap = rng.choice(cmaps)
        bytes_flag = rng.choice([False, True])
        has_alpha = rng.choice([False, True])
        alpha = rng.uniform(0.0, 1.0) if has_alpha else None

        # Half targeted at uint types and boundary values (issue triggers on unsigned/int array inputs)
        if i % 2 == 0:
            dtype = rng.choice([np.uint8, np.uint16, np.uint32, np.uint64, np.int8])
            shape_choice = rng.choice(["empty", "1d", "2d", "scalar"])
            if shape_choice == "empty":
                X = np.empty((0,), dtype=dtype)
            elif shape_choice == "scalar":
                val = rng.randint(0, 300)
                X = dtype(val)
            elif shape_choice == "1d":
                length = rng.randint(1, 10)
                vals = [rng.randint(0, 300) for _ in range(length)]
                X = np.array(vals, dtype=dtype)
            else:
                shape = (rng.randint(1, 4), rng.randint(1, 4))
                vals = [
                    rng.randint(0, 300)
                    for _ in range(shape[0] * shape[1])
                ]
                X = np.array(vals, dtype=dtype).reshape(shape)

            if rng.random() < 0.3 and X.size > 0:
                mask = np.array(
                    [rng.choice([True, False]) for _ in range(X.size)],
                    dtype=bool,
                ).reshape(X.shape)
                X = np.ma.masked_array(X, mask=mask)
        else:
            # Ordinary cases: floats, standard ints, masked arrays, NaNs
            kind = rng.choice(["float_scalar", "float_array", "int_scalar", "int_array"])
            if kind == "float_scalar":
                X = rng.choice([rng.uniform(-0.5, 1.5), float("nan")])
            elif kind == "int_scalar":
                X = rng.randint(-5, cmap.N + 5)
            elif kind == "int_array":
                shape = (rng.randint(1, 5),)
                vals = [rng.randint(-5, cmap.N + 5) for _ in range(shape[0])]
                X = np.array(vals, dtype=int)
            else:
                shape = (rng.randint(1, 4), rng.randint(1, 4))
                vals = [
                    rng.choice([rng.uniform(-0.2, 1.2), float("nan")])
                    for _ in range(shape[0] * shape[1])
                ]
                X = np.array(vals, dtype=float).reshape(shape)

        kwargs = {"bytes": bytes_flag}
        if alpha is not None:
            kwargs["alpha"] = alpha

        items.append((cmap, (X,), kwargs))

    return items
