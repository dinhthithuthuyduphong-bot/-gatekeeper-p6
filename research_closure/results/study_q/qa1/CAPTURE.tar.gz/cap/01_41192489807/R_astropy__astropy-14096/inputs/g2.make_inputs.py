def make_inputs(rng, n):
    SkyCoord = target_class if target_class is not None else module.SkyCoord
    u = module.u

    class SubSkyCoordPropMissing(SkyCoord):
        @property
        def bad_property(self):
            return self.non_existent_attribute_xyz

        @property
        def nested_bad_property(self):
            return getattr(self, "another_missing_attr")

        @property
        def bad_property_direct_err(self):
            raise AttributeError("custom attribute error inside property")

    class SubSkyCoordOther(SkyCoord):
        @property
        def valid_prop(self):
            return self.ra.deg * 2

    # Pre-create several coordinate instances to vary inputs
    c1 = SkyCoord(ra=10.0 * u.deg, dec=20.0 * u.deg, frame="icrs")
    c2 = SkyCoord("00h42m30s", "+41d12m00s", frame="fk5")
    c3 = SkyCoord(1.0, 2.0, unit="deg", frame="galactic")
    c_sub1 = SubSkyCoordPropMissing(10.0 * u.deg, 20.0 * u.deg, frame="icrs")
    c_sub2 = SubSkyCoordOther(30.0 * u.deg, -40.0 * u.deg, frame="icrs")

    # Half ordinary attributes (transforms, frame attributes, non-existent standard ones)
    ordinary_receivers = [c1, c2, c3, c_sub2]
    ordinary_attrs = [
        "galactic",
        "icrs",
        "fk5",
        "fk4",
        "ra",
        "dec",
        "l",
        "b",
        "obstime",
        "equinox",
        "nonexistent_attr_123",
        "random_attr",
        "bad_attr",
        "_sky_coord_frame",
        "frame",
    ]

    # Half issue-related attributes (triggering properties that raise AttributeError)
    issue_receivers = [c_sub1]
    issue_attrs = [
        "bad_property",
        "nested_bad_property",
        "bad_property_direct_err",
    ]

    items = []
    n_issue = n // 2
    n_ordinary = n - n_issue

    for _ in range(n_ordinary):
        rec = rng.choice(ordinary_receivers)
        attr = rng.choice(ordinary_attrs)
        items.append((rec, (attr,), {}))

    for _ in range(n_issue):
        rec = rng.choice(issue_receivers)
        attr = rng.choice(issue_attrs)
        items.append((rec, (attr,), {}))

    rng.shuffle(items)
    return items
