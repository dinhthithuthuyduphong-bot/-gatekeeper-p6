def make_inputs(rng, n):
    import sympy
    from sympy import Matrix, Symbol, symbols, S

    a, b, c, x, y = symbols('a b c x y')
    items = []

    for i in range(n):
        if i % 2 == 0:
            # Matrices related to the issue: symbolic entries where cancellations lead to
            # expressions that simplify to 0 but aren't trivially (syntactically) zero,
            # triggering invalid pivots and 0/0 (NaN) in bareiss recursion.
            pattern = rng.choice(['issue_exact', 'linear_combination', 'symbolic_structured', 'zeros_and_syms'])
            if pattern == 'issue_exact':
                dim = rng.choice([4, 5, 6])
                sym = rng.choice([a, b, x])
                mat = Matrix([[r + sym * c_idx for r in range(dim)] for c_idx in range(dim)])
            elif pattern == 'linear_combination':
                dim = rng.choice([3, 4, 5])
                sym = rng.choice([a, b, x])
                # Generate a rank-deficient or dependent symbolic matrix
                base = [[rng.randint(-2, 2) + rng.randint(-2, 2)*sym for _ in range(dim)] for _ in range(dim - 1)]
                # Last row is a linear combination of first two
                c1, c2 = rng.randint(-2, 2), rng.randint(-2, 2)
                last_row = [c1 * base[0][k] + c2 * base[1 % len(base)][k] for k in range(dim)]
                mat = Matrix(base + [last_row])
            elif pattern == 'symbolic_structured':
                dim = rng.choice([3, 4, 5])
                sym = rng.choice([a, b, c])
                mat = Matrix(dim, dim, lambda r, c_: (r - c_)*sym + (r + 1)*(c_ + 1))
            else:
                dim = rng.choice([3, 4, 5])
                # Top column has unexpanded zero or zeros with symbols
                sym = rng.choice([a, b])
                grid = []
                for r in range(dim):
                    row = []
                    for c_ in range(dim):
                        if c_ == 0 and r == 0:
                            row.append(sym - sym)  # zero
                        elif c_ == 0 and r == 1:
                            row.append((sym + 1)*(sym - 1) - (sym**2 - 1))  # simplifies to 0
                        else:
                            row.append(rng.choice([0, 1, -1, sym, sym + rng.randint(1, 3)]))
                    grid.append(row)
                mat = Matrix(grid)
        else:
            # Ordinary cases: varied sizes, small integers, simple symbols, full rank, 0-dim, 1-dim
            case = rng.choice(['zero_dim', 'one_dim', 'numeric', 'simple_sym', 'identity_like'])
            if case == 'zero_dim':
                mat = Matrix(0, 0, [])
            elif case == 'one_dim':
                val = rng.choice([0, 1, -5, a, a + 2])
                mat = Matrix([[val]])
            elif case == 'numeric':
                dim = rng.randint(2, 5)
                mat = Matrix([[rng.randint(-5, 5) for _ in range(dim)] for _ in range(dim)])
            elif case == 'identity_like':
                dim = rng.randint(2, 4)
                sym = rng.choice([a, b, 1])
                mat = Matrix.eye(dim) * sym
            else:
                dim = rng.randint(2, 4)
                syms = [a, b, 0, 1, -1, 2]
                mat = Matrix([[rng.choice(syms) for _ in range(dim)] for _ in range(dim)])

        items.append((mat, (), {}))

    return items
