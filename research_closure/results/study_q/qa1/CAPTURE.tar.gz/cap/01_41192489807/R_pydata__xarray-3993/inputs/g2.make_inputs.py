def make_inputs(rng, n):
    import numpy as np

    DataArray = target_class

    items = []
    coord_names = ["x", "y", "z", "time"]

    for i in range(n):
        # Create a sample DataArray
        nx = rng.randint(2, 6)
        ny = rng.randint(2, 6)
        data = np.arange(nx * ny, dtype=float).reshape(nx, ny)
        x_vals = np.sort(rng.sample([float(v) for v in range(20)], nx))
        y_vals = np.sort(rng.sample([float(v) for v in range(20)], ny))

        da = DataArray(
            data,
            dims=["x", "y"],
            coords={"x": x_vals, "y": y_vals},
        )

        # Decide input pattern:
        # Half of the tests target the difference/issue around `dim` vs `coord` keyword args.
        # The other half target positional argument calling or standard uses.
        choice = rng.choice(["positional", "coord_kw", "dim_kw", "both_kw", "neither_kw"])

        coord_to_integrate = rng.choice(["x", "y", ["x", "y"]])

        if i < n // 2:
            # Ordinary usage: positional argument
            args = (coord_to_integrate,)
            kwargs = {}
        else:
            # Exercising coord / dim keyword arguments
            sub_choice = rng.choice(["coord", "dim", "both", "neither"])
            if sub_choice == "coord":
                args = ()
                kwargs = {"coord": coord_to_integrate}
            elif sub_choice == "dim":
                args = ()
                kwargs = {"dim": coord_to_integrate}
            elif sub_choice == "both":
                args = ()
                kwargs = {"coord": coord_to_integrate, "dim": coord_to_integrate}
            else:
                args = ()
                kwargs = {}

        items.append((da, args, kwargs))

    return items
