from django.conf import settings
from django.core.files.storage import FileSystemStorage, default_storage

if not settings.configured:
    settings.configure(
        DEFAULT_FILE_STORAGE="django.core.files.storage.FileSystemStorage",
    )


def callable_returns_default():
    return default_storage


def make_inputs(rng, n):
    custom_storage_1 = FileSystemStorage(location="/custom/path/1")
    custom_storage_2 = FileSystemStorage(location="/custom/path/2")

    def callable_returns_custom_1():
        return custom_storage_1

    def callable_returns_custom_2():
        return custom_storage_2

    upload_to_options = [
        "",
        "uploads/",
        "docs/%Y/%m/%d/",
        lambda instance, filename: f"user_{instance}/{filename}",
    ]

    items = []
    for _ in range(n):
        is_bug_case = rng.random() < 0.5

        upload_to = rng.choice(upload_to_options)
        max_length = rng.choice([None, 100, 50, 200, 255])
        name = rng.choice([None, "my_file", "attachment", "document"])
        verbose_name = rng.choice([None, "Attachment", "User Upload"])

        kwargs = {}
        if max_length is not None:
            kwargs["max_length"] = max_length
        if verbose_name is not None:
            kwargs["verbose_name"] = verbose_name
        if name is not None:
            kwargs["name"] = name
        if rng.random() < 0.2:
            kwargs["blank"] = True

        if is_bug_case:
            storage = callable_returns_default
        else:
            storage = rng.choice(
                [
                    None,
                    default_storage,
                    custom_storage_1,
                    custom_storage_2,
                    callable_returns_custom_1,
                    callable_returns_custom_2,
                ]
            )

        field = module.FileField(upload_to=upload_to, storage=storage, **kwargs)
        items.append((field, (), {}))

    return items
