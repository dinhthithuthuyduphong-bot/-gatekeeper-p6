import types
from unittest.mock import MagicMock
from django.db import models


def make_inputs(rng, n):
    target_cls = getattr(module, "SQLInsertCompiler")

    # Custom wrapper class to verify converters
    class MyIntWrapper:
        def __init__(self, val):
            self.val = val

        def __eq__(self, other):
            return isinstance(other, MyIntWrapper) and self.val == other.val

        def __repr__(self):
            return f"MyIntWrapper({self.val})"

    class DummyFieldWithConverter:
        def __init__(self, name="id", col_name="id"):
            self.name = name
            self.column = col_name

        def get_col(self, target_table):
            return self

        def from_db_value(self, value, expression, connection):
            if value is None:
                return None
            return MyIntWrapper(value)

        def get_db_converters(self, connection):
            return [self.from_db_value]

    class DummyFieldPlain:
        def __init__(self, name="id", col_name="id"):
            self.name = name
            self.column = col_name

        def get_col(self, target_table):
            return self

        def get_db_converters(self, connection):
            return []

    class DummyMeta:
        def __init__(self, pk_field, db_table="test_table"):
            self.pk = pk_field
            self.db_table = db_table

    class DummyQuery:
        def __init__(self, objs, meta):
            self.objs = objs
            self._meta = meta

        def get_meta(self):
            return self._meta

    inputs = []
    for i in range(n):
        use_converters = i % 2 == 1

        # Configure fields
        if use_converters:
            pk_field = DummyFieldWithConverter()
        else:
            pk_field = DummyFieldPlain()

        meta = DummyMeta(pk_field)

        # Connection behavior configuration
        # 0: last_insert_id (neither returning features supported)
        # 1: can_return_columns_from_insert
        # 2: can_return_rows_from_bulk_insert
        mode = rng.choice([0, 1, 2])

        if mode == 2:
            num_objs = rng.randint(2, 5)
            can_bulk = True
            can_cols = rng.choice([True, False])
        else:
            num_objs = 1
            can_bulk = False
            can_cols = (mode == 1)

        returning_choice = rng.choice([None, [], [pk_field]])
        if i % 2 == 1 and not returning_choice:
            returning_choice = [pk_field]

        objs = [MagicMock() for _ in range(num_objs)]
        query = DummyQuery(objs, meta)

        features = MagicMock()
        features.can_return_rows_from_bulk_insert = can_bulk
        features.can_return_columns_from_insert = can_cols

        ops = MagicMock()
        return_int = rng.randint(1, 1000)

        if mode == 2:
            returned_rows = [(return_int + j,) for j in range(num_objs)]
            ops.fetch_returned_insert_rows.return_value = returned_rows
        elif mode == 1:
            ops.fetch_returned_insert_columns.return_value = (return_int,)
        else:
            ops.last_insert_id.return_value = return_int

        ops.get_db_converters.return_value = []

        cursor = MagicMock()
        cursor_ctx = MagicMock()
        cursor_ctx.__enter__.return_value = cursor
        cursor_ctx.__exit__.return_value = None

        connection = MagicMock()
        connection.features = features
        connection.ops = ops
        connection.cursor.return_value = cursor_ctx

        compiler = target_cls(query, connection, "default")
        compiler.returning_params = ()
        compiler.as_sql = MagicMock(return_value=[("INSERT INTO ...", ())])

        kwargs = {}
        if rng.choice([True, False]):
            kwargs["returning_fields"] = returning_choice
            args = ()
        else:
            args = (returning_choice,)

        inputs.append((compiler, args, kwargs))

    return inputs
