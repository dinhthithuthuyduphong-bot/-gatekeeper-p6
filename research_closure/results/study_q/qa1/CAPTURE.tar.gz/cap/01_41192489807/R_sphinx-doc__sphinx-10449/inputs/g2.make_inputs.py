from docutils import nodes


def make_inputs(rng, n):
    items = []
    param_pool = ['x', 'y', 'width', 'height', 'data', 'val', 'arg', 'cls', 'self']
    type_pool = ['int', 'str', 'bool', 'List[int]', 'Optional[str]', 'Any', 'None']

    for i in range(n):
        field_list = nodes.field_list()

        # Decide whether to populate existing fields in field_list
        num_existing = rng.randint(0, 3)
        for _ in range(num_existing):
            kind = rng.choice(['param', 'type', 'param_typed', 'rtype', 'other'])
            field = nodes.field()
            if kind == 'param':
                p_name = rng.choice(param_pool)
                field += nodes.field_name('', f'param {p_name}')
                field += nodes.field_body('', nodes.paragraph('', f'Documentation for {p_name}'))
            elif kind == 'type':
                p_name = rng.choice(param_pool)
                field += nodes.field_name('', f'type {p_name}')
                field += nodes.field_body('', nodes.paragraph('', rng.choice(type_pool)))
            elif kind == 'param_typed':
                p_name = rng.choice(param_pool)
                t_name = rng.choice(type_pool)
                field += nodes.field_name('', f'param {t_name} {p_name}')
                field += nodes.field_body('', nodes.paragraph('', f'Documentation for {p_name}'))
            elif kind == 'rtype':
                field += nodes.field_name('', 'rtype')
                field += nodes.field_body('', nodes.paragraph('', rng.choice(type_pool)))
            else:
                field += nodes.field_name('', 'returns')
                field += nodes.field_body('', nodes.paragraph('', 'Description of return'))
            field_list += field

        annotations = {}
        # Pick 0 to 4 parameters for annotations
        selected_params = rng.sample(param_pool, rng.randint(0, min(4, len(param_pool))))
        for p in selected_params:
            annotations[p] = rng.choice(type_pool)

        # Decide whether to include 'return' annotation
        if i % 2 == 0:
            # Focus on the issue: suppress_rtype and return annotations ('None' vs other types)
            include_return = True
            annotations['return'] = rng.choice(['None', 'int', 'str', 'None'])
            # Note: in Python default arguments or kwargs, if called with suppress_rtype
            # kwargs, older version will raise TypeError if passed as kwarg. To be compatible
            # with both signatures if tested dynamically or positional, kwargs should be tested carefully.
            # But notice the original signature only accepted (node, annotations), while the fix added
            # suppress_rtype=False as a default. If caller passes suppress_rtype=True as kwarg, original will fail!
            # However, differential testing calls modify_field_list with args/kwargs. If kwargs has suppress_rtype,
            # original fails with TypeError: modify_field_list() got an unexpected keyword argument.
            # Wait, does the test harness pass kwargs? If kwargs contains suppress_rtype, original raises TypeError!
            # BUT when testing callers, or testing modify_field_list directly, how is it invoked?
            # If the user asks to test `modify_field_list`, maybe suppress_rtype can only be used if supported,
            # OR suppress_rtype is tested via positional/kwargs. But wait! Original didn't have suppress_rtype.
            # Wait, if original doesn't have suppress_rtype, any call passing suppress_rtype will differ (TypeError vs success).
            # Wait, is suppress_rtype intended to be passed in kwargs?
            # Notice the prompt:
            # "We will call the function `modify_field_list` defined in `sphinx/ext/autodoc/typehints.py` many times,
            # once in the ORIGINAL version of the repository and once in the version that contains the upstream fix, and compare the results."
            # If suppress_rtype is passed, ORIGINAL raises TypeError. That is an observable difference, which differential testing might or might not want.
            # Wait! In the bug fix:
            # def modify_field_list(node: nodes.field_list, annotations: Dict[str, str],
            #                       suppress_rtype: bool = False) -> None:
            # And in the bug fix, 'annotation' bug was also fixed!
            # Look at original:
            #   for name, annotation in annotations.items():
            #   ...
            #   if 'return' in annotations and 'return' not in arguments:
            #       field = nodes.field()
            #       field += nodes.field_name('', 'rtype')
            #       field += nodes.field_body('', nodes.paragraph('', annotation))  <--- UNBOUND if annotations was empty or only had 'return'!
            # Wait! Look closely at the original:
            #   for name, annotation in annotations.items():
            #       if name == 'return':
            #           continue
            #   if 'return' in annotations and 'return' not in arguments:
            #       field += nodes.field_body('', nodes.paragraph('', annotation))
            # If annotations = {'return': 'int'}, the loop does `continue` on the only element!
            # `annotation` is 'int'!
            # BUT what if annotations only had 'return'?
            # `for name, annotation in annotations.items()` sets `annotation = 'int'`.
            # BUT what if annotations was `{}`?
            # Then `if 'return' in annotations` is False, so it's not reached.
            # BUT what if annotations had other keys, or 'return'?
            # Look at fix:
            #   if 'return' in annotations and 'return' not in arguments:
            # +     annotation = annotations['return']
            # In original, `annotation` in `field += nodes.field_body('', nodes.paragraph('', annotation))`
            # was the LEAKED loop variable from `for name, annotation in annotations.items()`!
            # If annotations had `{'x': 'int', 'return': 'str'}`:
            # The loop sets `annotation = 'str'` (if 'return' is last) or `annotation = 'int'` (if 'return' is first)!
            # In Python, dict order matters!
            # In original: `annotation` was NOT `annotations['return']`, it was whatever `annotation` was left from the loop!
            # Wow! Look at that:
            # In original:
            #   for name, annotation in annotations.items():
            #       if name == 'return':
            #           continue
            #       ...
            #   if 'return' in annotations and 'return' not in arguments:
            #       field = nodes.field()
            #       field += nodes.field_name('', 'rtype')
            #       field += nodes.field_body('', nodes.paragraph('', annotation))
            # If annotations = {'return': 'None'}, in Python the loop sets `name = 'return'`, `annotation = 'None'`, then `continue`.
            # If annotations = OrderedDict([('return', 'None'), ('x', 'int')]), then loop ends with `annotation = 'int'`,
            # so rtype got `nodes.paragraph('', 'int')` instead of `None`!
            # AND if suppress_rtype is tested:
            # Can we pass kwargs? If we pass `suppress_rtype`, original crashes with TypeError.
            # But wait: if caller calls with 2 arguments (node, annotations), can suppress_rtype be tested?
            # With 2 arguments, suppress_rtype is False in the fix!
            # But wait, why did the upstream add suppress_rtype to modify_field_list?
            # For merge_typehints:
            # if objtype == 'class':
            #     modify_field_list(field_list, annotations[fullname], suppress_rtype=True)
            # If make_inputs ONLY tests modify_field_list, can it pass suppress_rtype?
            # If we pass suppress_rtype in kwargs, original fails with TypeError.
            # Wait, the prompt says:
            # "We will call the function `modify_field_list` defined in `sphinx/ext/autodoc/typehints.py` many times,
            # once in the ORIGINAL version of the repository and once in the version that contains the upstream fix, and compare the results."
            # Some differential testers check if both return or if behavior changes. But usually differential testing expects both to run without unexpected signature mismatch, OR the test is checking the new keyword argument too.
            # Wait! Even WITHOUT suppress_rtype (i.e. only 2 args), `annotation = annotations['return']` is a fix!
            # In original:
            # annotations = {'a': 'int', 'return': 'str'} -> loop iterates 'a' (annotation='int'), then 'return' (continue, annotation='str').
            # annotations = {'return': 'str', 'a': 'int'} -> loop iterates 'return' (annotation='str'), then 'a' (annotation='int').
            # In original, rtype would get 'int' instead of 'str'!
            # And when suppress_rtype is used:
            # If rng generates some calls with suppress_rtype, what if original fails?
            # Is it safe to include suppress_rtype in some kwargs?
            # Yes, standard differential testing for a function whose signature was extended with an optional parameter often tests that parameter.
            # But to be safe, we can test:
            # 1) 2 arguments where dict ordering exposes the `annotation = annotations['return']` bug!
            # 2) kwargs with `suppress_rtype=True` and `suppress_rtype=False`.
        kwargs = {}
        if rng.random() < 0.4:
            # Provide suppress_rtype
            kwargs['suppress_rtype'] = rng.choice([True, False])

        # Return annotation variations
        if rng.random() < 0.7:
            ret_val = rng.choice(['None', 'int', 'str', 'bool', 'Any'])
            # vary placement of 'return' in annotations (first, middle, last)
            items_list = list(annotations.items())
            pos = rng.randint(0, len(items_list))
            items_list.insert(pos, ('return', ret_val))
            annotations = dict(items_list)

        items.append((None, (field_list, annotations), kwargs))

    return items
