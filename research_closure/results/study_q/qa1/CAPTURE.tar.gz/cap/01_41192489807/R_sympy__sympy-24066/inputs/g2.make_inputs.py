def make_inputs(rng, n):
    from sympy import exp, sin, cos, tan, log, S, Symbol, Integer
    from sympy.physics import units
    from sympy.physics.units.systems.si import SI

    funcs = [exp, sin, cos, tan, log]

    # Dimensionless expressions composed of derived/base units whose dimensions
    # are equivalent to Dimension(1) via the dimension system, but not syntactically Dimension(1).
    dimensionless_combos = [
        units.second / (units.ohm * units.farad),
        (units.meter / units.second) / (units.kilometer / units.hour),
        units.joule / (units.newton * units.meter),
        units.volt * units.coulomb / units.joule,
        units.watt / (units.volt * units.ampere),
        units.meter / units.meter,
        (units.ohm * units.siemens),
        units.hertz * units.second,
        units.tesla * units.meter**2 / units.weber,
        units.henry * units.ampere / (units.weber),
    ]

    # Base or simple units / dimensions
    standard_units = [
        units.meter,
        units.second,
        units.kilogram,
        units.ampere,
        units.kelvin,
        units.newton,
        units.joule,
        units.watt,
        units.volt,
        units.ohm,
    ]

    items = []
    half = n // 2

    # Issue-targeted inputs: transcendental/special functions of dimensionless expressions
    # that are not syntactically Dimension(1), often inside Add, Pow, Mul, etc.
    for _ in range(half):
        func = rng.choice(funcs)
        dim_expr = rng.choice(dimensionless_combos)
        scale = rng.choice([1, 2, 5, S.Half, -1, 10])
        inner = scale * dim_expr

        variant = rng.choice([0, 1, 2, 3, 4])
        if variant == 0:
            # Direct function call: e.g. exp(second / (ohm * farad))
            expr = func(inner)
        elif variant == 1:
            # Addition with a dimensionless scalar: e.g. 100 + exp(...)
            scalar = rng.choice([1, 10, 100, S.One])
            expr = scalar + func(inner)
        elif variant == 2:
            # Addition of two such functions
            f2 = rng.choice(funcs)
            d2 = rng.choice(dimensionless_combos)
            expr = func(inner) + f2(d2)
        elif variant == 3:
            # Inside a power or product: e.g. meter * exp(...) or exp(...)**2 + 1
            if rng.choice([True, False]):
                expr = rng.choice(standard_units) * func(inner)
            else:
                expr = (func(inner) ** 2) + 5
        else:
            # Nested function call: e.g. sin(exp(...)) or 1 + sin(exp(...))
            f2 = rng.choice(funcs)
            expr = 1 + f2(func(inner))

        items.append((SI, (expr,), {}))

    # Ordinary inputs: normal quantities, Mul, Pow, Add, functions of plain Dimension(1), etc.
    for _ in range(n - half):
        choice = rng.choice([0, 1, 2, 3, 4, 5, 6])
        if choice == 0:
            # Pure number or symbol
            expr = rng.choice([S.Zero, S.One, Integer(rng.randint(2, 100)), Symbol("x")])
        elif choice == 1:
            # Single unit
            expr = rng.choice(standard_units)
        elif choice == 2:
            # Simple product / power
            u1, u2 = rng.sample(standard_units, 2)
            expr = (u1 ** rng.choice([1, 2, -1, -2])) * (u2 ** rng.choice([1, 2, -1]))
        elif choice == 3:
            # Valid Add with same dimension
            u = rng.choice(standard_units)
            expr = rng.randint(1, 10) * u + rng.randint(1, 10) * u
        elif choice == 4:
            # Function with already syntactically dimensionless argument (pure number)
            func = rng.choice(funcs)
            arg = rng.choice([S.One, Integer(2), S.Half])
            expr = func(arg)
            if rng.choice([True, False]):
                expr = expr + 1
        elif choice == 5:
            # Function with dimensioned argument (non-dimensionless), checking dimension propagation
            func = rng.choice(funcs)
            u = rng.choice(standard_units)
            expr = func(u)
        else:
            # Power with dimensionless exponent
            u = rng.choice(standard_units)
            dim_expr = rng.choice(dimensionless_combos)
            expr = u ** (dim_expr + 1)

        items.append((SI, (expr,), {}))

    rng.shuffle(items)
    return items
