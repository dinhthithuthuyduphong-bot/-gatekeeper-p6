import sys
import types
from pathlib import Path

_orig_func = module.get_child_arguments

def _wrapped_get_child_arguments(argv=None, spec=None):
    import __main__
    old_argv = sys.argv
    old_spec = getattr(__main__, '__spec__', None)
    try:
        if argv is not None:
            sys.argv = argv
        if spec is not Ellipsis:
            if spec is None and hasattr(__main__, '__spec__'):
                delattr(__main__, '__spec__')
            elif spec is not None:
                __main__.__spec__ = spec
        return _orig_func()
    finally:
        sys.argv = old_argv
        if old_spec is None:
            if hasattr(__main__, '__spec__'):
                delattr(__main__, '__spec__')
        else:
            __main__.__spec__ = old_spec

module.get_child_arguments = _wrapped_get_child_arguments


def make_inputs(rng, n):
    items = []
    this_file = str(Path(__file__).resolve()) if '__file__' in globals() else sys.executable

    for i in range(n):
        # Decide argv
        num_args = rng.randint(1, 4)
        sub_args = [f"--arg{j}={rng.randint(0, 100)}" for j in range(num_args)]
        argv = [this_file] + sub_args

        # About half are ordinary uses (spec is None, or package -m run where spec.name is '__main__')
        # About half are the issue: dotted module name where spec.name is NOT '__main__' (or doesn't end with .__main__)
        is_issue_case = (i % 2 == 1)

        if not is_issue_case:
            mode = rng.choice(['none', 'missing', 'pkg_main', 'root_main'])
            if mode == 'missing':
                spec = None
            elif mode == 'none':
                spec = types.SimpleNamespace(name='__main__', parent=None)
            elif mode == 'pkg_main':
                pkg = rng.choice(['my_app', 'foo.bar', 'django.core'])
                spec = types.SimpleNamespace(name=f'{pkg}.__main__', parent=pkg)
            else:
                spec = types.SimpleNamespace(name='__main__', parent='my_project')
        else:
            # Issue cases: custom module run with -m custom_module.submodule
            parts = [f"mod_{rng.randint(1, 10)}" for _ in range(rng.randint(1, 3))]
            mod_name = ".".join(parts)
            parent_name = ".".join(parts[:-1]) if len(parts) > 1 else ""
            # In Python, when running `python -m a.b.c`, __spec__.name is 'a.b.c' and parent is 'a.b'
            spec = types.SimpleNamespace(name=mod_name, parent=parent_name)

        items.append((None, (), {'argv': argv, 'spec': spec}))

    return items
