import os
import re


def make_inputs(rng, n):
    items = []

    file_names = ["about.py", "design.py", "main.py", "utils.py", "test.py"]
    dir_names = ["src", "gen", "build", "tests", "sub"]

    for i in range(n):
        if i % 2 == 0:
            # Ordinary cases: simple normalized paths or direct basenames
            subdirs = [rng.choice(dir_names) for _ in range(rng.randint(0, 3))]
            fname = rng.choice(file_names)
            element = os.path.join(*subdirs, fname) if subdirs else fname

            ignore_list = rng.sample(
                ["about.py", "setup.py", "build", ".git"], rng.randint(0, 2)
            )
            ignore_list_re = [
                re.compile(p)
                for p in rng.sample([r"^test_.*", r".*\.tmp$"], rng.randint(0, 2))
            ]
            ignore_list_paths_re = [
                re.compile(p)
                for p in rng.sample(
                    [r"^src[\\/]gen[\\/].*", r"^build[\\/].*"], rng.randint(0, 2)
                )
            ]
        else:
            # Cases with redundant path components like './', '../', '//'
            # which os.path.normpath(element) simplifies and affects ignore_list_paths_re
            prefix_choices = [
                "./",
                ".\\",
                "src/../src/",
                "src/./",
                "./src/gen/../gen/",
                "foo/bar/../../src/gen/",
                "src//gen/",
                "tests/../",
            ]
            prefix = rng.choice(prefix_choices)
            fname = rng.choice(file_names)
            sub = rng.choice(["gen/", "", "nested/"])
            raw_element = f"{prefix}{sub}{fname}"
            # On windows vs posix, convert separators sometimes to test normpath
            if rng.random() < 0.5:
                raw_element = raw_element.replace("/", os.sep)

            element = raw_element

            ignore_list = rng.sample(["about.py", "design.py"], rng.randint(0, 1))
            ignore_list_re = [
                re.compile(p)
                for p in rng.sample([r"^about.*", r"^sub.*"], rng.randint(0, 1))
            ]

            # Regexes constructed to match normalized paths
            path_patterns = [
                r"^src[\\/]gen[\\/].*$",
                r"^src[\\/].*",
                r"^gen[\\/].*",
                r"^tests[\\/].*",
            ]
            ignore_list_paths_re = [
                re.compile(p)
                for p in rng.sample(path_patterns, rng.randint(1, len(path_patterns)))
            ]

        items.append(
            (
                None,
                (element, ignore_list, ignore_list_re, ignore_list_paths_re),
                {},
            )
        )

    return items
