def make_inputs(rng, n):
    import django
    from django.conf import settings
    from django.db import models
    from django.contrib.admin import ModelAdmin
    from django.contrib.admin.sites import AdminSite

    if not settings.configured:
        settings.configure(
            DATABASES={"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": ":memory:"}},
            INSTALLED_APPS=[
                "django.contrib.auth",
                "django.contrib.contenttypes",
                "django.contrib.admin",
            ],
            SECRET_KEY="dummy",
        )
        django.setup()

    class Country(models.Model):
        name = models.CharField(max_length=256)

        class Meta:
            app_label = "admin"

    class Place(models.Model):
        country = models.ForeignKey(Country, models.CASCADE)
        name = models.CharField(max_length=100)

        class Meta:
            app_label = "admin"

    class Restaurant(models.Model):
        place = models.OneToOneField(Place, models.CASCADE, primary_key=True)
        serves_hot_dogs = models.BooleanField(default=False)

        class Meta:
            app_label = "admin"

    class Waiter(models.Model):
        restaurant = models.ForeignKey(Restaurant, models.CASCADE)
        name = models.CharField(max_length=50)

        class Meta:
            app_label = "admin"

    class Person(models.Model):
        name = models.CharField(max_length=50)

        class Meta:
            app_label = "admin"

    class Employee(Person):
        department_name = models.CharField(max_length=50)

        class Meta:
            app_label = "admin"

    class Project(models.Model):
        lead = models.ForeignKey(Employee, models.CASCADE)

        class Meta:
            app_label = "admin"

    site = AdminSite()

    class WaiterAdmin(ModelAdmin):
        list_filter = [
            "restaurant__place__country",
            "restaurant__place__name",
            "restaurant__serves_hot_dogs",
            "name",
        ]
        date_hierarchy = None

    class ProjectAdmin(ModelAdmin):
        list_filter = [
            "lead__name",
            "lead__department_name",
            "lead__person_ptr",
        ]
        date_hierarchy = None

    class PlaceAdmin(ModelAdmin):
        list_filter = ["country__name", "name"]
        date_hierarchy = None

    waiter_admin = WaiterAdmin(Waiter, site)
    project_admin = ProjectAdmin(Project, site)
    place_admin = PlaceAdmin(Place, site)

    fk_pk_lookups = [
        (waiter_admin, "restaurant__place__country", "1"),
        (waiter_admin, "restaurant__place__country__name", "USA"),
        (waiter_admin, "restaurant__place__country__id", "1"),
        (waiter_admin, "restaurant__place__name", "Diner"),
        (waiter_admin, "restaurant__serves_hot_dogs", "True"),
        (waiter_admin, "restaurant__place", "1"),
        (waiter_admin, "restaurant__place__exact", "1"),
        (waiter_admin, "restaurant__place__country__exact", "1"),
        (waiter_admin, "restaurant__country", "1"),
        (waiter_admin, "restaurant__country__name", "USA"),
    ]

    ordinary_lookups = [
        (waiter_admin, "name", "Bob"),
        (waiter_admin, "name__exact", "Alice"),
        (waiter_admin, "unknown_field", "val"),
        (waiter_admin, "restaurant__unknown", "val"),
        (place_admin, "country__name", "Canada"),
        (place_admin, "country__id", "2"),
        (place_admin, "name", "Central"),
        (project_admin, "lead__name", "Charlie"),
        (project_admin, "lead__department_name", "IT"),
        (project_admin, "lead__id", "1"),
        (project_admin, "lead__person_ptr", "1"),
        (project_admin, "lead__person_ptr__id", "1"),
        (project_admin, "lead__person_ptr__name", "Charlie"),
        (project_admin, "nonexistent__lookup__chain", "foo"),
    ]

    items = []
    for _ in range(n):
        if rng.random() < 0.5:
            admin, lookup, val = rng.choice(fk_pk_lookups)
        else:
            admin, lookup, val = rng.choice(ordinary_lookups)

        val_to_use = str(rng.randint(0, 100)) if rng.random() < 0.2 else val
        items.append((admin, (lookup, val_to_use), {}))

    return items
