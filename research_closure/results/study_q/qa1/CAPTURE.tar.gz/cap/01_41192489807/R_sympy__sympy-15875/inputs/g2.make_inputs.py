def make_inputs(rng, n):
    import sympy
    from sympy import S, I, Symbol, Add

    items = []

    # Symbols with various assumptions
    x_real = Symbol('x_r', real=True)
    x_real_nz = Symbol('x_rnz', real=True, zero=False)
    x_imag = Symbol('x_im', imaginary=True)
    x_imag_nz = Symbol('x_imnz', imaginary=True, zero=False)
    x_c = Symbol('x_c', complex=True)
    x_gen = Symbol('x_gen')

    for i in range(n):
        # Around half should target the bug: len(nz) == 0 with complex/imaginary parts
        # e.g., -2*I + (1 + I)**2 where no args are strictly real non-zero, but some are imaginary / complex
        # Note: Add(..., evaluate=False) can be used to construct specific Add instances
        if i % 2 == 0:
            choice = rng.randint(0, 5)
            if choice == 0:
                # The exact issue: -2*I + (1 + I)**2
                # In SymPy, (1 + I)**2 evaluates to 2*I if evaluated, but with evaluate=False:
                expr = Add(-2*I, (1 + I)**2, evaluate=False)
            elif choice == 1:
                # Other powers of complex numbers with imaginary components
                c = rng.choice([-2, -1, 1, 2]) + rng.choice([-2, -1, 1, 2]) * I
                pow_c = (c)**2
                expr = Add(-pow_c, pow_c, evaluate=False)
            elif choice == 2:
                # Imaginary term plus complex term that may or may not be zero
                k = rng.choice([-3, -2, -1, 1, 2, 3])
                expr = Add(k * I, (rng.choice([1, -1]) + I)**2, evaluate=False)
            elif choice == 3:
                # Multiple imaginary or complex expressions without any real term (len(nz) == 0)
                terms = [rng.choice([-2, -1, 1, 2]) * I, (rng.choice([-1, 1]) + rng.choice([-1, 1])*I)**2]
                if rng.random() < 0.5:
                    terms.append(x_imag)
                expr = Add(*terms, evaluate=False)
            elif choice == 4:
                # Purely imaginary / (I*a).is_real expressions without real terms
                terms = [(1 + I)**2, -(1 + I)**2]
                expr = Add(*terms, evaluate=False)
            else:
                # Non-zero imaginary + (I*a).is_real
                expr = Add(I, (1 - I)**2, evaluate=False)
        else:
            # Ordinary cases: all real, symbols, zeros, evaluated expressions
            choice = rng.randint(0, 5)
            if choice == 0:
                # Evaluated real expressions
                c1 = rng.randint(-5, 5)
                c2 = rng.randint(-5, 5)
                expr = Add(c1, c2, evaluate=False)
            elif choice == 1:
                # Expressions with zeros
                expr = Add(S.Zero, S.Zero, evaluate=False)
            elif choice == 2:
                # Mixed real non-zeros
                expr = Add(S(1), S(2), evaluate=False)
            elif choice == 3:
                # Mixed real non-zero and imaginary
                expr = Add(S(1), I, evaluate=False)
            elif choice == 4:
                # Symbols
                syms = rng.sample([x_real, x_real_nz, x_imag, x_imag_nz, x_c, x_gen], k=rng.randint(1, 3))
                expr = Add(*syms, evaluate=False)
            else:
                # Real non-zero sum canceling
                expr = Add(S(2), S(-2), evaluate=False)

        # Make sure the receiver is an Add instance
        if not isinstance(expr, Add):
            expr = Add(expr, evaluate=False)

        items.append((expr, (), {}))

    return items
