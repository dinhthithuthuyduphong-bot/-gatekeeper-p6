def make_inputs(rng, n):
    import sympy
    from sympy.utilities.lambdify import implemented_function
    from sympy.core.numbers import Float, Integer

    f1 = implemented_function('f1_custom', lambda x: x**2)
    f2 = implemented_function('g2_custom', lambda x: 2 * x + 1)
    f3 = implemented_function('h3_custom', lambda x, y: x + y)
    f_const = implemented_function('c_custom', lambda: 42)
    f_float_strict = implemented_function('strict_custom', lambda x: float(x) + 0.5)

    standard_funcs = [sympy.sin, sympy.cos, sympy.exp, sympy.log]

    items = []
    for _ in range(n):
        prec = rng.choice([15, 30, 53, 64, 100])
        # About half the time test nested/composition implemented_functions
        if rng.random() < 0.5:
            # Issue-related: implemented functions composed with other implemented functions,
            # or with sympy expressions that need evalf to turn into python numbers/floats
            case = rng.choice(['nested_imp', 'nested_imp_multi', 'expr_in_imp', 'sympy_func_in_imp'])
            if case == 'nested_imp':
                val = Integer(rng.randint(-10, 10))
                g_inner = f2(val)
                receiver = f1(g_inner)
            elif case == 'nested_imp_multi':
                x_val = Integer(rng.randint(-5, 5))
                y_val = Integer(rng.randint(-5, 5))
                receiver = f3(f1(x_val), f2(y_val))
            elif case == 'expr_in_imp':
                x_val = sympy.Rational(rng.randint(1, 10), rng.randint(1, 10))
                receiver = f_float_strict(x_val)
            else:
                x_val = Integer(rng.randint(1, 5))
                receiver = f_float_strict(sympy.sin(x_val))
        else:
            # Ordinary cases: built-in sympy functions, pure numbers, or un-nested implemented_function
            case = rng.choice(['builtin', 'simple_imp', 'symbolic_imp'])
            if case == 'builtin':
                fn = rng.choice(standard_funcs)
                val = sympy.Rational(rng.randint(-5, 5), rng.randint(1, 5))
                receiver = fn(val)
            elif case == 'simple_imp':
                val = Float(rng.uniform(-10.0, 10.0))
                receiver = rng.choice([f1, f2])(val)
            else:
                # Symbolic input that might fail to evaluate to float
                receiver = f1(sympy.Symbol('x'))

        items.append((receiver, (prec,), {}))

    return items
