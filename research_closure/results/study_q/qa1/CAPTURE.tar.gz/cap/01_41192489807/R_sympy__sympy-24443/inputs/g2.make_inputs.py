def make_inputs(rng, n):
    from sympy.combinatorics.named_groups import (
        DihedralGroup, CyclicGroup, SymmetricGroup, AlternatingGroup
    )
    from sympy.combinatorics.free_groups import free_group
    from sympy.combinatorics.fp_groups import FpGroup

    items = []

    # Pre-build some standard groups
    D3 = DihedralGroup(3)
    D4 = DihedralGroup(4)
    C2 = CyclicGroup(2)
    C3 = CyclicGroup(3)
    C4 = CyclicGroup(4)
    C6 = CyclicGroup(6)
    S3 = SymmetricGroup(3)
    S4 = SymmetricGroup(4)
    A4 = AlternatingGroup(4)

    # Some FP groups
    F2, x, y = free_group("x, y")
    Fp_c2 = FpGroup(F2, [x**2, y, x*y*x**-1*y**-1])
    Fp_c4 = FpGroup(F2, [x**4, y, x*y*x**-1*y**-1])
    Fp_d3 = FpGroup(F2, [x**3, y**2, x*y*x*y])

    perm_groups = [D3, D4, C2, C3, C4, C6, S3, S4, A4]
    fp_groups = [Fp_c2, Fp_c4, Fp_d3]

    for i in range(n):
        # Half inputs target the issue: PermutationGroup as domain
        # where presentation relators typically contain inverted generators.
        if i % 2 == 0:
            G = rng.choice(perm_groups)
            mode = rng.choice(["id", "trivial", "random_images"])
            if mode == "id":
                # Identity map G -> G
                images = {g: g for g in G.generators}
                codomain = G
            elif mode == "trivial":
                # Trivial map G -> H (mapping all generators to identity)
                codomain = rng.choice(perm_groups + fp_groups)
                images = {g: codomain.identity for g in G.generators}
            else:
                # Target codomain is another perm group, possibly valid or invalid homomorphism
                codomain = rng.choice(perm_groups)
                cod_gens = codomain.generators + [codomain.identity]
                images = {g: rng.choice(cod_gens) for g in G.generators}
            items.append((None, (G, codomain, images), {}))
        else:
            # Other inputs: FpGroup domain or FreeGroup domain
            domain_choice = rng.choice(["fp", "free"])
            if domain_choice == "fp":
                G = rng.choice(fp_groups)
                mode = rng.choice(["id", "trivial", "to_perm"])
                if mode == "id":
                    codomain = G
                    images = {g: g for g in G.generators}
                elif mode == "trivial":
                    codomain = rng.choice(perm_groups + fp_groups)
                    images = {g: codomain.identity for g in G.generators}
                else:
                    # Map Fp_d3 to D3
                    codomain = D3
                    if G == Fp_d3:
                        # generators x (order 3), y (order 2)
                        d3_rot = D3.generators[0]
                        d3_flip = D3.generators[1]
                        images = {G.generators[0]: d3_rot, G.generators[1]: d3_flip}
                    else:
                        images = {g: rng.choice(list(codomain.generators) + [codomain.identity]) for g in G.generators}
                items.append((None, (G, codomain, images), {}))
            else:
                # FreeGroup domain
                F, a, b = free_group(f"a_{i}, b_{i}")
                codomain = rng.choice(perm_groups + fp_groups)
                # FreeGroup has no relators, any mapping is a homomorphism
                cod_elems = list(codomain.generators) + [codomain.identity]
                images = {a: rng.choice(cod_elems), b: rng.choice(cod_elems)}
                items.append((None, (F, codomain, images), {}))

    return items
