import types
import uuid
from django.conf import settings
from django.db import models

if not settings.configured:
    settings.configure(
        DATABASES={
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': ':memory:',
            }
        },
        INSTALLED_APPS=[
            'django.contrib.contenttypes',
            'django.contrib.auth',
        ],
    )
    import django
    django.setup()


class MockBaseManager:
    def using(self, alias):
        return self


class DummyPKDefaultModel(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4)
    name = models.CharField(max_length=100, default='test')

    class Meta:
        app_label = 'differential_testing_pk_default'

    def _do_update(self, base_qs, using, pk_val, values, update_fields, forced_update):
        return getattr(self, '_mock_update_result', False)

    def _do_insert(self, base_manager, using, fields, returning_fields, raw):
        return []


class DummyNormalModel(models.Model):
    name = models.CharField(max_length=100, default='test')

    class Meta:
        app_label = 'differential_testing_normal'

    def _do_update(self, base_qs, using, pk_val, values, update_fields, forced_update):
        return getattr(self, '_mock_update_result', False)

    def _do_insert(self, base_manager, using, fields, returning_fields, raw):
        return [getattr(self, 'id', 1)] if returning_fields else []


def make_inputs(rng, n):
    items = []

    for i in range(n):
        # Target the difference in _save_table:
        # In original:
        #   if (not force_insert and self._state.adding and self._meta.pk.default and self._meta.pk.default is not NOT_PROVIDED):
        #       force_insert = True
        # In upstream fix:
        #   if (not raw and not force_insert and self._state.adding and self._meta.pk.default and self._meta.pk.default is not NOT_PROVIDED):
        #       force_insert = True
        #
        # When raw=True, adding=True, pk has default:
        # Original forces insert (returns False because updated is False).
        # Fixed attempts update first, and if _do_update returns True, returns True!

        is_fix_scenario = (i % 2 == 0)

        if is_fix_scenario:
            model_cls = DummyPKDefaultModel
            raw = rng.choice([True, True, False])
            adding = rng.choice([True, False])
            pk_val = uuid.uuid4()
            update_result = rng.choice([True, False])
            force_insert = False
            force_update = False
        else:
            model_cls = rng.choice([DummyPKDefaultModel, DummyNormalModel])
            raw = rng.choice([True, False])
            adding = rng.choice([True, False])
            pk_val = uuid.uuid4() if model_cls is DummyPKDefaultModel else (rng.randint(1, 1000) if rng.choice([True, False]) else None)
            update_result = rng.choice([True, False])
            force_insert = rng.choice([True, False])
            force_update = rng.choice([True, False]) if pk_val is not None else False

        instance = model_cls()
        if pk_val is not None:
            instance.pk = pk_val
        instance._state.adding = adding
        instance._mock_update_result = update_result

        kwargs = {
            'raw': raw,
            'cls': model_cls,
            'force_insert': force_insert,
            'force_update': force_update,
            'using': 'default',
            'update_fields': None,
        }

        items.append((instance, (), kwargs))

    return items
