from types import SimpleNamespace
from unittest.mock import MagicMock

def make_inputs(rng, n):
    items = []

    class MockField:
        def __init__(self, name, unique=False):
            self.name = name
            self.unique = unique

    class MockConstraint:
        def __init__(self, fields):
            self.fields = tuple(fields)

    for i in range(n):
        # Determine whether to test normal cases or UniqueConstraint cases
        is_constraint_case = (i % 2 == 1)

        # Build mock model and meta
        fields_dict = {
            'id': MockField('id', unique=True),
            'email': MockField('email', unique=not is_constraint_case),
            'slug': MockField('slug', unique=False),
            'code': MockField('code', unique=False),
            'non_unique': MockField('non_unique', unique=False),
        }

        if is_constraint_case:
            # Add total_unique_constraints to meta
            mode = rng.choice(['single_slug', 'single_code', 'multi_field', 'empty'])
            if mode == 'single_slug':
                constraints = [MockConstraint(['slug'])]
                chosen_field = 'slug'
            elif mode == 'single_code':
                constraints = [MockConstraint(['code'])]
                chosen_field = 'code'
            elif mode == 'multi_field':
                constraints = [MockConstraint(['slug', 'code'])]
                chosen_field = 'slug'
            else:
                constraints = []
                chosen_field = 'slug'
        else:
            constraints = []
            chosen_field = rng.choice(['pk', 'id', 'email', 'non_unique'])

        meta = SimpleNamespace(
            get_field=lambda fname, d=fields_dict: d.get(fname, MockField(fname, unique=False)),
            total_unique_constraints=constraints,
        )

        model = SimpleNamespace(_meta=meta)

        qs = target_class.__new__(target_class)
        qs.model = model
        qs._db = 'default'
        qs._hints = {}
        qs._result_cache = None
        qs._sticky_filter = False
        qs._for_write = False
        qs._prefetch_related_lookups = ()
        qs._prefetch_done = False
        qs._known_related_objects = {}
        qs._fields = None
        qs._defer_next_filter = False
        qs._deferred_filter = None

        query_mock = MagicMock()
        query_mock.is_sliced = False
        qs._query = query_mock

        # Setup filter and chain behaviors on QuerySet
        result_objs = [SimpleNamespace(id=1, email='a@example.com', slug='slug-a', code='c1', non_unique='val')]
        filtered_qs = MagicMock()
        filtered_qs.order_by.return_value = result_objs
        qs.filter = MagicMock(return_value=filtered_qs)
        qs._chain = MagicMock(return_value=result_objs)

        # Empty id_list allows avoiding extensive db / connection interactions
        id_list = rng.choice([[], [1, 2], None])

        args = ()
        kwargs = {'field_name': chosen_field}
        if id_list is not None:
            args = (id_list,)

        items.append((qs, args, kwargs))

    return items
