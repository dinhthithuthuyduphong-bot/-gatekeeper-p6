import django
from django.conf import settings
from django.db import models
from django.db.models import Q
from django.forms import Field, ModelChoiceField

if not settings.configured:
    settings.configure(
        DATABASES={
            'default': {
                'ENGINE': 'django.db.backends.sqlite3',
                'NAME': ':memory:',
            }
        },
        INSTALLED_APPS=[
            'django.contrib.contenttypes',
            'django.contrib.auth',
        ],
    )
    django.setup()


class DummyQuerySet:
    def __init__(self, model):
        self.model = model
        self.filters = []

    def complex_filter(self, filter_obj):
        res = DummyQuerySet(self.model)
        res.filters = list(self.filters) + [('complex_filter', filter_obj)]
        return res

    def filter(self, *args, **kwargs):
        res = DummyQuerySet(self.model)
        res.filters = list(self.filters) + [('filter', args, kwargs)]
        return res


class DummyManager:
    def __init__(self, model):
        self.model = model

    def filter(self, *args, **kwargs):
        qs = DummyQuerySet(self.model)
        return qs.filter(*args, **kwargs)


class DummyModel:
    pass

DummyModel._base_manager = DummyManager(DummyModel)


class MockFormField:
    def __init__(self, queryset=None, limit_choices_to=None, has_qs=True, has_get_limit=True):
        if has_qs:
            self.queryset = queryset
        if has_get_limit:
            self._limit_choices_to = limit_choices_to

    def get_limit_choices_to(self):
        return self._limit_choices_to


def make_inputs(rng, n):
    items = []

    # Variety of limit_choices_to values
    q_choices = [
        Q(is_active=True),
        Q(name__startswith="A") | Q(name__startswith="B"),
        Q(membership__is_valid=True),  # join involved
        Q(),
        {'is_active': True},
        {'is_staff': False, 'score__gt': 10},
        {},
        None,
    ]

    for i in range(n):
        # Determine case type
        scenario = rng.choice(['ordinary', 'no_attributes', 'q_object', 'dict_limit', 'falsy_limit'])

        if scenario == 'no_attributes':
            # Edge case: formfield missing either queryset or get_limit_choices_to
            has_qs = rng.choice([True, False])
            has_limit = False if has_qs else rng.choice([True, False])
            field = MockFormField(
                queryset=DummyQuerySet(DummyModel) if has_qs else None,
                limit_choices_to=Q(id__gt=0),
                has_qs=has_qs,
                has_get_limit=has_limit,
            )
        elif scenario == 'falsy_limit':
            # Empty Q or empty dict or None
            lim = rng.choice([None, {}, Q()])
            field = MockFormField(
                queryset=DummyQuerySet(DummyModel),
                limit_choices_to=lim,
                has_qs=True,
                has_get_limit=True,
            )
        elif scenario == 'dict_limit':
            lim = rng.choice([{'is_active': True}, {'score__gte': rng.randint(1, 100)}])
            field = MockFormField(
                queryset=DummyQuerySet(DummyModel),
                limit_choices_to=lim,
                has_qs=True,
                has_get_limit=True,
            )
        else:
            # Q object with potential joins or simple filter
            lim = rng.choice(q_choices)
            field = MockFormField(
                queryset=DummyQuerySet(DummyModel),
                limit_choices_to=lim,
                has_qs=True,
                has_get_limit=True,
            )

        items.append((None, (field,), {}))

    return items
