import numpy as np


def make_inputs(rng, n):
    LogisticRegressionCV = getattr(module, "LogisticRegressionCV")
    items = []

    solvers = ["lbfgs", "liblinear", "saga", "newton-cg"]

    for i in range(n):
        # Target issue specifically: refit=False with multi_class='auto' (or ovr vs multinomial),
        # penalty choices, and binary vs multiclass targets.
        refit = False if (i % 2 == 0) else True

        n_samples = rng.randint(40, 70)
        n_features = rng.randint(2, 5)

        # Decide binary vs multiclass
        is_binary = rng.choice([True, False])
        n_classes = 2 if is_binary else rng.choice([3, 4])

        multi_class = rng.choice(["auto", "ovr", "multinomial"])

        # Select compatible solver & penalty
        if rng.random() < 0.2:
            penalty = "elasticnet"
            solver = "saga"
            l1_ratios = [0.1, 0.5, 0.9]
        elif rng.random() < 0.4:
            penalty = "l1"
            solver = rng.choice(["liblinear", "saga"])
            l1_ratios = None
        else:
            penalty = "l2"
            solver = rng.choice(solvers)
            l1_ratios = None

        # liblinear does not support multinomial
        if solver == "liblinear" and multi_class == "multinomial":
            solver = "lbfgs"

        cv = rng.choice([2, 3])
        Cs = rng.choice([2, 3])

        X = np.array(
            [[rng.gauss(0, 1) for _ in range(n_features)] for _ in range(n_samples)],
            dtype=np.float64,
        )

        # Ensure all classes are present across folds
        y = np.array([j % n_classes for j in range(n_samples)], dtype=np.int64)
        rng_perm = rng.sample(range(n_samples), n_samples)
        y = y[rng_perm]

        clf = LogisticRegressionCV(
            Cs=Cs,
            cv=cv,
            penalty=penalty,
            solver=solver,
            refit=refit,
            multi_class=multi_class,
            l1_ratios=l1_ratios,
            max_iter=50,
            tol=1e-3,
            random_state=rng.randint(0, 10000),
        )

        items.append((clf, (X, y), {}))

    return items
