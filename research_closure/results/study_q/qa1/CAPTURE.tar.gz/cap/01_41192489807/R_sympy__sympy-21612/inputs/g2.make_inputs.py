def make_inputs(rng, n):
    from sympy import symbols, Mul, Pow, S, Integer, Rational, Add

    printer = module.StrPrinter()
    a, b, c, d, x, y, z = symbols('a b c d x y z')
    symbols_list = [a, b, c, d, x, y, z]

    items = []

    # Target cases: Pow with exp = -1 where base is a Pow (or Mul) having len(base.args) != 1.
    # The diff changes `isinstance(item.base, Mul)` to `isinstance(item.base, (Mul, Pow))`.
    # When item = Pow(Pow(base_b, base_e, evaluate=False), -1, evaluate=False),
    # item.base is a Pow (which has len(item.args[0].args) == 2 != 1).
    # Then `item.base` gets added to `pow_paren` and gets extra parentheses when printed in denominator.

    def make_target_mul(rng):
        # A Mul containing a factor Pow(Pow(u, v, evaluate=False), -1, evaluate=False)
        # Often with another numerator or denominator factor.
        u = rng.choice(symbols_list)
        v = rng.choice([Integer(2), Integer(-2), Integer(3), Integer(-1), rng.choice(symbols_list)])
        inner_pow = Pow(u, v, evaluate=False)

        # Factor in denominator with exp = -1
        target_denom_factor = Pow(inner_pow, S.NegativeOne, evaluate=False)

        num_choices = [
            rng.choice(symbols_list),
            Add(rng.choice(symbols_list), rng.choice(symbols_list)),
            Rational(rng.randint(1, 5), rng.randint(2, 6)),
            Pow(rng.choice(symbols_list), rng.choice([Integer(2), Integer(3)])),
            S.One,
        ]
        num_factor = rng.choice(num_choices)

        extra = rng.choice([
            [],
            [Pow(rng.choice(symbols_list), S.NegativeOne, evaluate=False)],
            [rng.choice(symbols_list)],
        ])

        all_args = [num_factor, target_denom_factor] + extra
        if rng.random() < 0.2:
            return Mul(*all_args)
        else:
            return Mul(*all_args, evaluate=False)

    def make_ordinary_mul(rng):
        # Ordinary expressions: products, rational numbers, negative exponents, additions
        t = rng.randint(0, 5)
        if t == 0:
            s1, s2 = rng.sample(symbols_list, 2)
            return Mul(s1, s2)
        elif t == 1:
            s1, s2 = rng.sample(symbols_list, 2)
            k = rng.choice([-3, -2, -1, 1, 2, 3])
            return Mul(s1, Pow(s2, k))
        elif t == 2:
            s1, s2, s3 = rng.sample(symbols_list, 3)
            return Mul(s1, s2, Pow(s3, -1))
        elif t == 3:
            s1, s2 = rng.sample(symbols_list, 2)
            return Mul(Rational(rng.randint(-5, 5), rng.randint(1, 5)), s1, Pow(s2, -1))
        elif t == 4:
            s1, s2, s3 = rng.sample(symbols_list, 3)
            return Mul(Add(s1, s2), Pow(s3, -1), evaluate=False)
        else:
            s1, s2, s3 = rng.sample(symbols_list, 3)
            # Unevaluated Mul or Mul base
            inner_mul = Mul(s1, s2, evaluate=False)
            return Mul(s3, Pow(inner_mul, S.NegativeOne, evaluate=False), evaluate=False)

    n_target = n // 2
    n_ordinary = n - n_target

    for _ in range(n_target):
        expr = make_target_mul(rng)
        items.append((printer, (expr,), {}))

    for _ in range(n_ordinary):
        expr = make_ordinary_mul(rng)
        items.append((printer, (expr,), {}))

    rng.shuffle(items)
    return items
