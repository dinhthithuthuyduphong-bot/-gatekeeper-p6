import io
from astropy.io.fits import BinTableHDU, GroupsHDU, HDUList, TableHDU
from astropy.io.fits.hdu.hdulist import FITS_SIGNATURE


def make_inputs(rng, n):
    items = []

    fits_exts = [".fits", ".fits.gz", ".fit", ".fit.gz", ".fts", ".fts.gz"]
    non_fits_exts = [".ecsv", ".csv", ".txt", ".hdf5", ".json", ".xml", "", ".dat"]
    origins = ["read", "write"]

    for i in range(n):
        origin = rng.choice(origins)

        # About half the time test the issue: filepath is a non-FITS path (or any filepath)
        # where args may be empty (causing IndexError: tuple index out of range in original)
        # or contain objects.
        if i % 2 == 0:
            # Bug/issue triggering cases: filepath is provided, usually non-fits extension,
            # and args can be empty (typical in registry call: args=()).
            ext = rng.choice(non_fits_exts)
            name = "".join(rng.choices("abcdefghijklmnopqrstuvwxyz1234567890_", k=rng.randint(3, 10)))
            filepath = f"{name}{ext}"
            fileobj = None

            # Often args is empty, triggering IndexError in original if ext is not fits
            if rng.random() < 0.7:
                extra_args = ()
            else:
                # Sometimes extra args is provided
                extra_args = (rng.choice([123, "test", None]),)

            kwargs = {}
            items.append((None, (origin, filepath, fileobj, *extra_args), kwargs))
        else:
            # Ordinary cases: fileobj provided, or FITS filepath provided, or filepath is None with HDU object
            case_type = rng.choice(["fileobj", "fits_filepath", "hdu_args"])

            if case_type == "fileobj":
                is_valid_fits = rng.choice([True, False])
                if is_valid_fits:
                    content = FITS_SIGNATURE + b" " * 50
                else:
                    content = b"random content not matching fits sig"
                bio = io.BytesIO(content)
                # optionally seek somewhere
                if rng.random() < 0.3:
                    bio.seek(rng.randint(0, 5))
                filepath = rng.choice([None, "test.fits", "test.txt"])
                extra_args = ()
                items.append((None, (origin, filepath, bio, *extra_args), {}))

            elif case_type == "fits_filepath":
                ext = rng.choice(fits_exts)
                # optionally uppercase/mixed case
                if rng.random() < 0.3:
                    ext = ext.upper()
                name = "".join(rng.choices("abcdefghijklmnopqrstuvwxyz", k=rng.randint(3, 8)))
                filepath = f"{name}{ext}"
                extra_args = ()
                items.append((None, (origin, filepath, None, *extra_args), {}))

            else:  # hdu_args with filepath=None and fileobj=None
                filepath = None
                fileobj = None
                hdu_cls = rng.choice([HDUList, TableHDU, BinTableHDU, GroupsHDU, int, str, object])
                if hdu_cls in (HDUList, TableHDU, BinTableHDU, GroupsHDU):
                    # Construct an instance or mock
                    try:
                        arg0 = hdu_cls()
                    except Exception:
                        arg0 = object()
                else:
                    arg0 = hdu_cls()

                extra_args = (arg0,)
                items.append((None, (origin, filepath, fileobj, *extra_args), {}))

    return items
