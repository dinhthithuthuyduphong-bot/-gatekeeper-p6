import numpy as np


def make_inputs(rng, n):
    items = []
    dtypes_list = [np.float64, np.float32, np.int32, np.int64]

    for i in range(n):
        # Half ordinary single axis / None axis, half multiple axes (tuple)
        is_multi_axis = (i % 2 == 1)

        # Generate mask shape
        ndim = rng.randint(2, 4)
        shape = tuple(rng.randint(2, 5) for _ in range(ndim))
        mask = rng.choice([0, 1]) * (rng.random() < 0.3)
        # full mask array
        mask = np.array(
            [[rng.random() < 0.3 for _ in range(shape[-1])] for _ in range(int(np.prod(shape[:-1])))],
            dtype=bool,
        ).reshape(shape)

        if is_multi_axis:
            # Tuple of axes
            num_axes = rng.randint(2, ndim)
            axis = tuple(sorted(rng.sample(range(ndim), num_axes)))
            # Sometimes all axes
            if rng.random() < 0.2:
                axis = tuple(range(ndim))
        else:
            # Single integer axis or None
            if rng.random() < 0.2:
                axis = None
            else:
                axis = rng.randint(0, ndim - 1)

        # Generate result array matching the reduction
        dt = rng.choice(dtypes_list)
        if axis is None:
            res_shape = ()
        elif isinstance(axis, int):
            res_shape = shape[:axis] + shape[axis + 1:]
        else:
            res_shape = tuple(s for idx, s in enumerate(shape) if idx not in axis)

        if res_shape == ():
            result = dt(rng.uniform(-10, 10))
        else:
            result = np.array(
                [rng.uniform(-10, 10) for _ in range(int(np.prod(res_shape)))],
                dtype=dt,
            ).reshape(res_shape)

        # Determine min_count
        if axis is None:
            max_count = mask.size
        elif isinstance(axis, int):
            max_count = shape[axis]
        else:
            max_count = int(np.prod([shape[a] for a in axis]))

        min_count = rng.randint(0, max_count + 2)

        items.append((None, (result, axis, mask), {"min_count": min_count}))

    return items
