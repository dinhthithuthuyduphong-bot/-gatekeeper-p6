import datetime
import decimal
from django.db import models
from django.forms.fields import InvalidJSONInput


def make_inputs(rng, n):
    items = []

    # Various field types for testing
    char_field = models.CharField(max_length=50)
    int_field = models.IntegerField()
    float_field = models.FloatField()
    decimal_field = models.DecimalField(max_digits=5, decimal_places=2)
    bool_field = models.BooleanField()
    date_field = models.DateField()
    datetime_field = models.DateTimeField()
    time_field = models.TimeField()
    choice_field = models.CharField(max_length=10, choices=[("a", "Alpha"), ("b", "Beta")])
    json_field = models.JSONField()

    json_values = [
        {"foo": "bar"},
        {"a": 1, "b": [1, 2, 3], "c": True, "d": None},
        [1, "two", 3.0, {"nested": False}],
        "just a string",
        12345,
        True,
        False,
        {},
        [],
        "",
        None,
        InvalidJSONInput("{invalid json}"),
        object(),  # non-serializable object to trigger TypeError
        {"date": datetime.date(2020, 1, 1)},  # Might fail or work depending on encoder
    ]

    other_cases = [
        ("hello world", char_field),
        (None, char_field),
        (42, int_field),
        (-100, int_field),
        (None, int_field),
        (3.14159, float_field),
        (decimal.Decimal("12.34"), decimal_field),
        (True, bool_field),
        (False, bool_field),
        (None, bool_field),
        (datetime.date(2021, 5, 20), date_field),
        (datetime.datetime(2021, 5, 20, 14, 30, 0), datetime_field),
        (datetime.time(14, 30, 0), time_field),
        ("a", choice_field),
        ("unknown", choice_field),
        (None, choice_field),
    ]

    empty_displays = ["-", "(None)", "Empty", ""]

    for i in range(n):
        empty_val = rng.choice(empty_displays)
        if rng.random() < 0.5:
            # Focus on JSONField behaviour
            val = rng.choice(json_values)
            items.append((None, (val, json_field, empty_val), {}))
        else:
            # Standard behaviour
            val, fld = rng.choice(other_cases)
            items.append((None, (val, fld, empty_val), {}))

    return items
