def make_inputs(rng, n):
    from sympy import Symbol, S, Integer, Rational, Float, I, pi
    from sympy.core.mod import Mod

    symbols = [
        Symbol('i', integer=True),
        Symbol('j', integer=True, positive=True),
        Symbol('k', integer=True, negative=True),
        Symbol('x'),
        Symbol('y'),
        Symbol('n', integer=True),
        Symbol('m', even=True),
        Symbol('p', odd=True),
    ]

    items = []
    half = n // 2

    # Target specific inputs related to the issue/fix:
    # Mod(Mul, Integer) where Mul contains an Integer coefficient and mod_l is empty
    # e.g., Mod(3*i, 2), Mod(7*k, 3), Mod(15*x*i, 4), etc.
    for _ in range(half):
        sym = rng.choice(symbols)
        # Random non-zero integer divisor q != 1
        q_val = rng.choice([-7, -5, -4, -3, -2, 2, 3, 4, 5, 6, 7, 8, 10, 12])
        q = Integer(q_val)
        
        # Multiple factors in p
        coeff = rng.choice([-15, -12, -9, -7, -6, -5, -3, 3, 5, 6, 7, 9, 10, 11, 14, 15, 20])
        
        pattern = rng.choice([0, 1, 2, 3])
        if pattern == 0:
            p = Integer(coeff) * sym
        elif pattern == 1:
            sym2 = rng.choice(symbols)
            p = Integer(coeff) * sym * sym2
        elif pattern == 2:
            p = Integer(coeff) * (sym + 1)
        else:
            # multiple numeric factors that Mul might fold
            p = Integer(coeff) * sym * Integer(rng.choice([2, 3, 5]))

        items.append((Mod, (p, q), {}))

    # General / ordinary inputs for Mod.eval
    for _ in range(n - half):
        choice = rng.choice([0, 1, 2, 3, 4, 5, 6, 7])
        if choice == 0:
            # numbers only
            p = Integer(rng.randint(-50, 50))
            q = Integer(rng.choice([-10, -5, -3, -2, -1, 1, 2, 3, 5, 10]))
        elif choice == 1:
            # Symbol % Symbol
            p = rng.choice(symbols)
            q = rng.choice(symbols)
        elif choice == 2:
            # Add expression % number/symbol
            p = rng.choice(symbols) + Integer(rng.randint(-10, 10))
            q = rng.choice([Integer(2), Integer(3), Integer(5), rng.choice(symbols)])
        elif choice == 3:
            # Rationals / Floats
            p = Rational(rng.randint(-10, 10), rng.randint(1, 5))
            q = Rational(rng.randint(1, 10), rng.randint(1, 5))
        elif choice == 4:
            # Existing Mod nested
            inner_sym = rng.choice(symbols)
            p = Mod(inner_sym, Integer(rng.choice([2, 3, 4])))
            q = Integer(rng.choice([2, 3, 4, 6]))
        elif choice == 5:
            # Mul with mod_l present (handled even before fix)
            sym = rng.choice(symbols)
            inner_mod = Mod(sym, Integer(3))
            p = Integer(rng.choice([2, 4, 5])) * inner_mod
            q = Integer(3)
        elif choice == 6:
            # gcd cancellation cases: e.g. Mod(6*x, 4) or Mod(3*x*i, 2*y*i)
            sym = rng.choice(symbols)
            p = Integer(rng.choice([4, 6, 8, 12])) * sym
            q = Integer(rng.choice([2, 4, 6]))
        else:
            # edge cases: p == 0, p == q, -q, etc.
            sym = rng.choice(symbols)
            edge = rng.choice(['zero', 'equal', 'neg_equal', 'one_q'])
            if edge == 'zero':
                p, q = S.Zero, sym
            elif edge == 'equal':
                p, q = sym, sym
            elif edge == 'neg_equal':
                p, q = -sym, sym
            else:
                p, q = sym, S.One

        items.append((Mod, (p, q), {}))

    return items
