def make_inputs(rng, n):
    import numpy as np

    # Specific interesting float cases where str(v) differs from f"{v:.16G}"
    # (e.g. 0.009125, values with fewer digits in str(), numpy float types, exponents)
    interesting_floats = [
        0.009125,
        0.0,
        -0.0,
        1.0,
        -1.0,
        0.1,
        0.2,
        0.3,
        1.2345678901234567,
        1e-4,
        1e-5,
        1e-6,
        1e15,
        1e16,
        1e20,
        1e-20,
        -1e-20,
        0.0001234567890123456,
        0.00001234567890123456,
        1234567890123456.0,
        12345678901234567.0,
        1.0000000000000002,
        0.9999999999999999,
        float("inf"),
        float("-inf"),
        float("nan"),
    ]

    items = []
    for i in range(n):
        if i < len(interesting_floats) and rng.random() < 0.6:
            val = interesting_floats[i % len(interesting_floats)]
        elif rng.random() < 0.5:
            # Floats that trigger decimal precision differences like 0.009125
            # Values like k / 2**m or k / 10**m
            base = rng.choice([0.009125, 0.000125, 0.075, 0.005, 0.12345, 0.54321])
            mult = rng.choice([1, 2, 3, 5, 7, 10, 0.1, 0.01])
            val = base * mult
            if rng.random() < 0.5:
                val = -val
        else:
            # Ordinary random floats across scales
            choice = rng.randint(0, 4)
            if choice == 0:
                val = rng.uniform(-1000.0, 1000.0)
            elif choice == 1:
                val = 10.0 ** rng.uniform(-30, 30)
                if rng.random() < 0.5:
                    val = -val
            elif choice == 2:
                # Random float near integer
                val = float(rng.randint(-10000, 10000))
            elif choice == 3:
                # Long representation floats
                val = rng.random() / rng.choice([3, 7, 11, 13, 17])
            else:
                val = rng.gauss(0, 1)

        # Occasionally cast to numpy float types
        if rng.random() < 0.2:
            val = rng.choice([np.float32, np.float64])(val)

        items.append((None, (val,), {}))

    return items
