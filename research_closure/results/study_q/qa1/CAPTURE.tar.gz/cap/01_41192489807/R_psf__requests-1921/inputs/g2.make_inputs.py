def make_inputs(rng, n):
    items = []

    dict_classes = [
        module.OrderedDict,
        dict,
        module.CaseInsensitiveDict,
    ]

    keys_pool = [
        "Accept-Encoding",
        "User-Agent",
        "Authorization",
        "Content-Type",
        "X-Custom-Header",
        "accept-encoding",
        "user-agent",
        "foo",
        "bar",
        "baz",
    ]

    values_pool = [
        "gzip, deflate",
        "requests/test",
        "Bearer token",
        "application/json",
        "custom-val",
        "123",
        "",
    ]

    def random_dict(cls, allow_none=False):
        d = cls()
        k_count = rng.randint(0, 5)
        chosen_keys = rng.sample(keys_pool, min(k_count, len(keys_pool)))
        for k in chosen_keys:
            if allow_none and rng.random() < 0.4:
                d[k] = None
            else:
                d[k] = rng.choice(values_pool)
        return d

    for i in range(n):
        # Decide if this is a targeted case or ordinary case
        is_targeted = (i % 2 == 1)

        dict_class = rng.choice(dict_classes)
        req_cls = rng.choice(dict_classes)
        sess_cls = rng.choice(dict_classes)

        if is_targeted:
            # The issue is when session_setting contains None values (e.g. session.headers['Accept-Encoding'] = None)
            # and request_setting does not override it or overrides something else.
            session_setting = sess_cls()
            # Ensure at least one None in session_setting
            session_setting[rng.choice(keys_pool)] = None
            for _ in range(rng.randint(0, 3)):
                k = rng.choice(keys_pool)
                session_setting[k] = None if rng.random() < 0.5 else rng.choice(values_pool)

            # Request setting could be a dict (with or without None, or empty)
            if rng.random() < 0.1:
                request_setting = None
            else:
                request_setting = random_dict(req_cls, allow_none=True)

            kwargs = {}
            if rng.random() < 0.3:
                kwargs["dict_class"] = dict_class
            items.append((None, (request_setting, session_setting), kwargs))

        else:
            # Ordinary cases: non-mappings, None values, standard dicts without None in session
            case_type = rng.choice(["none_settings", "non_mapping", "standard_dict", "req_has_none"])

            if case_type == "none_settings":
                req = None if rng.random() < 0.5 else random_dict(req_cls, allow_none=False)
                sess = None if rng.random() < 0.5 else random_dict(sess_cls, allow_none=False)
            elif case_type == "non_mapping":
                non_mappings = [True, False, 123, "verify_path", ["cert.pem"], ("user", "pass")]
                req = rng.choice(non_mappings)
                sess = rng.choice(non_mappings)
            elif case_type == "req_has_none":
                # request setting explicitly removes a session key via None
                sess = random_dict(sess_cls, allow_none=False)
                req = random_dict(req_cls, allow_none=False)
                if sess:
                    shared_k = rng.choice(list(sess.keys()))
                    req[shared_k] = None
            else:  # standard_dict
                req = random_dict(req_cls, allow_none=False)
                sess = random_dict(sess_cls, allow_none=False)

            kwargs = {}
            if rng.random() < 0.3:
                kwargs["dict_class"] = dict_class
            items.append((None, (req, sess), kwargs))

    return items
