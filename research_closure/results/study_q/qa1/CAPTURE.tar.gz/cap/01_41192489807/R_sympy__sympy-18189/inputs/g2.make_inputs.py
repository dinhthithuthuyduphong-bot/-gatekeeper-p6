def make_inputs(rng, n):
    from sympy.core.symbol import symbols

    items = []
    a, b, c, m, n_sym, x, y, z = symbols("a b c m n x y z")
    sym_pool = [a, b, c, m, n_sym, x, y, z]

    # Pre-defined base equations suitable for diophantine solver
    # Some with sum of squares/even powers (affected by permute=True)
    eq_templates = [
        lambda u, v: u**4 + v**4 - (2**4 + 3**4),
        lambda u, v: u**2 + v**2 - 25,
        lambda u, v: u**2 + v**2 - 13,
        lambda u, v: u**2 + v**2 - 5,
        lambda u, v: u**2 + v**2 - 1,
        lambda u, v: u**4 + v**4 - 17,
        lambda u, v: u**2 - v**2,
        lambda u, v: 2 * u + 3 * v - 5,
        lambda u, v: 3 * u - 4 * v - 1,
        lambda u, v: u * v - 6,
        lambda u, v: u**2 - 2 * v**2 - 1,
    ]

    three_var_templates = [
        lambda u, v, w: u**2 + v**2 + w**2 - 14,
        lambda u, v, w: u**2 + v**2 + w**2 - 29,
        lambda u, v, w: u**2 + v**2 - w**2,
        lambda u, v, w: u + 2 * v + 3 * w - 6,
    ]

    for i in range(n):
        # roughly half targets the bug: permute=True with syms specified in non-default order
        is_bug_target = (i % 2 == 1)

        if is_bug_target:
            # 2 or 3 vars, permute=True, syms reversed or shuffled
            permute = True
            if rng.random() < 0.75:
                # 2 vars
                s1, s2 = rng.sample(sym_pool, 2)
                eq_fn = rng.choice(eq_templates)
                eq = eq_fn(s1, s2)
                # Ensure syms != sorted(var)
                free = sorted(list(eq.free_symbols), key=lambda s: s.name)
                if len(free) == 2:
                    syms = [free[1], free[0]]
                else:
                    syms = [s2, s1]
            else:
                # 3 vars
                s1, s2, s3 = rng.sample(sym_pool, 3)
                eq_fn = rng.choice(three_var_templates)
                eq = eq_fn(s1, s2, s3)
                free = sorted(list(eq.free_symbols), key=lambda s: s.name)
                if len(free) >= 2:
                    syms = list(free)
                    while syms == free and len(syms) > 1:
                        rng.shuffle(syms)
                else:
                    syms = [s3, s2, s1]

            kwargs = {"syms": syms, "permute": permute}
            items.append((None, (eq,), kwargs))
        else:
            # Ordinary usage: default syms, permute=False/True, or syms in default order
            permute = rng.choice([False, True])
            if rng.random() < 0.6:
                s1, s2 = rng.sample(sym_pool, 2)
                eq = rng.choice(eq_templates)(s1, s2)
            else:
                s1, s2, s3 = rng.sample(sym_pool, 3)
                eq = rng.choice(three_var_templates)(s1, s2, s3)

            choice = rng.random()
            if choice < 0.33:
                kwargs = {"permute": permute}
            elif choice < 0.66:
                free = sorted(list(eq.free_symbols), key=lambda s: s.name)
                kwargs = {"syms": free, "permute": permute}
            else:
                kwargs = {"permute": False}

            items.append((None, (eq,), kwargs))

    return items
